// ==================== Service Worker للتطبيق ====================
const CACHE_NAME = 'mawaqit-otmani-v1';

const urlsToCache = [
    './',
    './index.html',
    './style.css',
    './script.js',
    'https://cdn.jsdelivr.net/npm/whatwg-fetch@3.6.2/dist/fetch.umd.min.js'
];

self.addEventListener('install', event => {
    console.log('✅ Service Worker: جاري التثبيت...');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('✅ Service Worker: تم فتح التخزين المؤقت');
                return cache.addAll(urlsToCache);
            })
            .catch(err => console.error('❌ خطأ:', err))
    );
    self.skipWaiting();
});

self.addEventListener('activate', event => {
    console.log('✅ Service Worker: جاري التنشيط...');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cache => {
                    if (cache !== CACHE_NAME) {
                        console.log('🗑️ حذف التخزين القديم:', cache);
                        return caches.delete(cache);
                    }
                })
            );
        })
    );
    self.clients.claim();
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                if (response) {
                    return response;
                }
                return fetch(event.request).then(response => {
                    if (!response || response.status !== 200 || response.type !== 'basic') {
                        return response;
                    }
                    const responseToCache = response.clone();
                    caches.open(CACHE_NAME)
                        .then(cache => {
                            cache.put(event.request, responseToCache);
                        });
                    return response;
                });
            })
    );
});