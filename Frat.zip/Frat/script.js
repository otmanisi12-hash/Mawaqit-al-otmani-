// ==================== 1. إعدادات التطبيق الأساسية ====================
let adSettings = {
    type: "flash",
    text: "",
    image: null,
    tickerEnabled: true,
    tickerText: "مرحباً بكم في مسجد التقوى - نسأل الله القبول - صلوا على النبي",
    tickerDirection: "rtl",
    flashEnabled: false,
    disableAll: false
};

const MAGHRIB_EXTRA_MINUTES = 3;

let prayerTimes = { fajr: "05:00", dhuhr: "12:30", asr: "15:30", maghrib: "18:45", isha: "20:00" };
let prayerAdjust = { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };
let prayerDurations = { fajr: 15, dhuhr: 15, asr: 15, maghrib: 15, isha: 15 };
let iqamaTimes = { fajr: 10, dhuhr: 10, asr: 10, maghrib: 5, isha: 10 };
let fridaySettings = { time: "12:30", duration: 30 };
let shutdownSettings = { enabled: false, shutdownTime: "22:00", wakeupTime: "04:00" };
let popupSettings = { enabled: true, interval: 5 };
let prayerMethod = "auto";

let permanentAdDisabled = false;
let asrSchool = 0;
let midnightMode = 1;
let highLatitudeMethod = "none";

let currentPrayerState = null;
let prayerSequenceTimers = [];
let azanActive = false;
let flashAdInterval = null;
let popupTimer = null;
let currentIqamaTimeout = null;
let lastCheckedPrayer = null;
let prayerMonitoringInterval = null;

// ==================== 2. الأحاديث النبوية (150 حديثاً) ====================
const hadithsList = [
    { text: "إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى", source: "رواه البخاري ومسلم" },
    { text: "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه", source: "رواه البخاري ومسلم" },
    { text: "بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان", source: "رواه البخاري ومسلم" },
    { text: "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت", source: "رواه البخاري ومسلم" },
    { text: "المؤمن للمؤمن كالبنيان يشد بعضه بعضاً", source: "رواه البخاري ومسلم" },
    { text: "مثل المؤمنين في توادهم وتراحمهم وتعاطفهم مثل الجسد إذا اشتكى منه عضو تداعى له سائر الجسد بالسهر والحمى", source: "رواه مسلم" },
    { text: "كلمتان خفيفتان على اللسان ثقيلتان في الميزان حبيبتان إلى الرحمن: سبحان الله وبحمده، سبحان الله العظيم", source: "رواه البخاري ومسلم" },
    { text: "اتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن", source: "رواه الترمذي" },
    { text: "إن الصدق يهدي إلى البر، وإن البر يهدي إلى الجنة", source: "رواه البخاري ومسلم" },
    { text: "أفضل الذكر لا إله إلا الله، وأفضل الدعاء الحمد لله", source: "رواه الترمذي" },
    { text: "من صام رمضان إيماناً واحتساباً غفر له ما تقدم من ذنبه", source: "رواه البخاري ومسلم" },
    { text: "من قال: لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير، في يوم مائة مرة، كانت له عدل عشر رقاب", source: "رواه البخاري ومسلم" },
    { text: "كلمة حكمة ضالة المؤمن فحيث وجدها فهو أحق بها", source: "رواه الترمذي" },
    { text: "الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء", source: "رواه الترمذي" },
    { text: "لا تحاسدوا، ولا تناجشوا، ولا تباغضوا، ولا تدابروا، وكونوا عباد الله إخواناً", source: "رواه البخاري ومسلم" },
    { text: "لا يؤمن أحدكم حتى أكون أحب إليه من والده وولده والناس أجمعين", source: "رواه البخاري ومسلم" },
    { text: "من حسن إسلام المرء تركه ما لا يعنيه", source: "رواه الترمذي" },
    { text: "تبسمك في وجه أخيك صدقة", source: "رواه الترمذي" },
    { text: "لا تحقرن من المعروف شيئاً، ولو أن تلقى أخاك بوجه طلق", source: "رواه مسلم" },
    { text: "الدال على الخير كفاعله", source: "رواه الترمذي" },
    { text: "المسلم من سلم المسلمون من لسانه ويده", source: "رواه البخاري ومسلم" },
    { text: "ليس الشديد بالصرعة، إنما الشديد الذي يملك نفسه عند الغضب", source: "رواه البخاري ومسلم" },
    { text: "لقد سألت عن عظيم، وإنه ليسير على من يسره الله عليه: تعبد الله ولا تشرك به شيئاً، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت", source: "رواه الترمذي" },
    { text: "من كان يؤمن بالله واليوم الآخر فليكرم ضيفه", source: "رواه البخاري ومسلم" },
    { text: "من كان يؤمن بالله واليوم الآخر فلا يؤذي جاره", source: "رواه البخاري ومسلم" },
    { text: "إياكم والجلوس في الطرقات، فأعطوا الطريق حقه: غض البصر، وكف الأذى، ورد السلام، والأمر بالمعروف، والنهي عن المنكر", source: "رواه البخاري ومسلم" },
    { text: "لله تسعة وتسعون اسماً، من أحصاها دخل الجنة", source: "رواه البخاري ومسلم" },
    { text: "من نفس عن مؤمن كربة من كرب الدنيا نفس الله عنه كربة من كرب يوم القيامة", source: "رواه مسلم" },
    { text: "من سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة", source: "رواه مسلم" },
    { text: "الرجل على دين خليله، فلينظر أحدكم من يخالل", source: "رواه أبو داود" },
    { text: "المؤمن مرآة المؤمن", source: "رواه أبو داود" },
    { text: "إن من أحبكم إلي وأقربكم مني مجلساً يوم القيامة أحاسنكم أخلاقاً", source: "رواه الترمذي" },
    { text: "المسلم من سلم المسلمون من لسانه ويده، والمهاجر من هجر ما نهى الله عنه", source: "رواه البخاري" },
    { text: "لا يدخل الجنة من لا يأمن جاره بوائقه", source: "رواه مسلم" },
    { text: "من دعا إلى هدى كان له من الأجر مثل أجور من تبعه لا ينقص ذلك من أجورهم شيئاً", source: "رواه مسلم" },
    { text: "أفضل الصدقة أن تتصدق وأنت صحيح شحيح، تأمل الغنى وتخشى الفقر", source: "رواه البخاري" },
    { text: "كل سلامى من الناس عليه صدقة كل يوم تطلع فيه الشمس، تعدل بين اثنين صدقة", source: "رواه البخاري ومسلم" },
    { text: "أكمل المؤمنين إيماناً أحسنهم خلقاً، وخياركم خياركم لنسائهم", source: "رواه الترمذي" },
    { text: "رضا الله في رضا الوالدين، وسخط الله في سخط الوالدين", source: "رواه الترمذي" },
    { text: "إن الله لا ينظر إلى صوركم وأموالكم، ولكن ينظر إلى قلوبكم وأعمالكم", source: "رواه مسلم" },
    { text: "عليكم بالصدق فإن الصدق يهدي إلى البر، وإن البر يهدي إلى الجنة", source: "رواه البخاري ومسلم" },
    { text: "إن الله طيب لا يقبل إلا طيباً، وإن الله أمر المؤمنين بما أمر به المرسلين", source: "رواه مسلم" },
    { text: "نعمتان مغبون فيهما كثير من الناس: الصحة والفراغ", source: "رواه البخاري" },
    { text: "بادروا بالأعمال فتناً كقطع الليل المظلم", source: "رواه مسلم" },
    { text: "من أحب أن يبسط له في رزقه، وأن ينسأ له في أثره، فليصل رحمه", source: "رواه البخاري ومسلم" },
    { text: "ليس الواصل بالمكافئ، ولكن الواصل الذي إذا قُطعت رحمه وصلها", source: "رواه البخاري" },
    { text: "أطعموا الجائع، وعودوا المريض، وفكوا العاني", source: "رواه البخاري" },
    { text: "حق المسلم على المسلم ست: إذا لقيته فسلّم عليه، وإذا دعاك فأجبه، وإذا استنصحك فانصح له، وإذا عطس فحمد الله فشمّته، وإذا مرض فعده، وإذا مات فاتبعه", source: "رواه مسلم" },
    { text: "من يرد الله به خيراً يفقهه في الدين", source: "رواه البخاري ومسلم" },
    { text: "ازهد في الدنيا يحبك الله، وازهد فيما عند الناس يحبك الناس", source: "رواه ابن ماجه" },
    { text: "من صلى على واحدة صلى الله عليه بها عشراً", source: "رواه مسلم" },
    { text: "كن في الدنيا كأنك غريب أو عابر سبيل", source: "رواه البخاري" },
    { text: "إياكم والظن فإن الظن أكذب الحديث، ولا تجسسوا، ولا تحسسوا، وكونوا عباد الله إخواناً", source: "رواه البخاري ومسلم" },
    { text: "أفضل الصلاة بعد الفريضة صلاة الليل", source: "رواه مسلم" },
    { text: "من قرأ حرفاً من كتاب الله فله به حسنة والحسنة بعشر أمثالها", source: "رواه الترمذي" },
    { text: "خفف على الناس ولا تعسّر، وبشّر ولا تنفّر", source: "رواه البخاري ومسلم" },
    { text: "لو كانت الدنيا تعدل عند الله جناح بعوضة ما سقى كافراً منها شربة ماء", source: "رواه الترمذي" },
    { text: "الكلمة الطيبة صدقة", source: "رواه البخاري ومسلم" },
    { text: "أحب الأعمال إلى الله أدومها وإن قل", source: "رواه البخاري ومسلم" },
    { text: "من تواضع لله رفعه الله", source: "رواه مسلم" },
    { text: "ما نقصت صدقة من مال، وما زاد الله عبداً بعفو إلا عزاً", source: "رواه مسلم" },
    { text: "سبعة يظلهم الله في ظله يوم لا ظل إلا ظله: إمام عادل، وشاب نشأ في عبادة الله، ورجل قلبه معلق في المساجد", source: "رواه البخاري ومسلم" },
    { text: "التائب من الذنب كمن لا ذنب له", source: "رواه ابن ماجه" },
    { text: "إن الله يقبل التوبة ما لم يُغرغر", source: "رواه الترمذي" },
    { text: "الظلم ظلمات يوم القيامة", source: "رواه البخاري ومسلم" },
    { text: "سباب المسلم فسوق، وقتاله كفر", source: "رواه البخاري ومسلم" },
    { text: "خياركم أحاسنكم أخلاقاً", source: "رواه البخاري" },
    { text: "من سئل عن علم فكتمه ألجم يوم القيامة بلجام من نار", source: "رواه الترمذي" },
    { text: "الصدقة على المسكين صدقة، وعلى ذي الرحم اثنتان: صدقة وصلة", source: "رواه الترمذي" },
    { text: "المسلم أخو المسلم لا يظلمه ولا يسلمه", source: "رواه البخاري ومسلم" },
    { text: "الحياء شعبة من الإيمان", source: "رواه البخاري ومسلم" },
    { text: "لا يدخل الجنة من كان في قلبه مثقال ذرة من كبر", source: "رواه مسلم" },
    { text: "من كان يؤمن بالله واليوم الآخر فليصل رحمه", source: "رواه البخاري" },
    { text: "الندم توبة", source: "رواه ابن ماجه" },
    { text: "الدين النصيحة", source: "رواه مسلم" },
    { text: "المؤمن القوي خير وأحب إلى الله من المؤمن الضعيف وفي كل خير", source: "رواه مسلم" },
    { text: "أحب البلاد إلى الله مساجدها", source: "رواه مسلم" },
    { text: "صلاة الجماعة تفضل صلاة الفذ بسبع وعشرين درجة", source: "رواه البخاري ومسلم" },
    { text: "من توضأ فأحسن الوضوء ثم قال: أشهد أن لا إله إلا الله وحده لا شريك له وأشهد أن محمداً عبده ورسوله، فتحت له أبواب الجنة الثمانية", source: "رواه مسلم" },
    { text: "ما من مسلم يتوضأ فيحسن الوضوء ثم يقوم فيصلي ركعتين مقبل عليهما بقلبه ووجهه إلا وجبت له الجنة", source: "رواه مسلم" },
    { text: "أول ما يحاسب به العبد يوم القيامة الصلاة", source: "رواه النسائي" },
    { text: "من حافظ عليها كانت له نوراً وبرهاناً ونجاة يوم القيامة", source: "رواه أحمد" },
    { text: "من صلى البردين دخل الجنة", source: "رواه البخاري ومسلم" },
    { text: "ركعتا الفجر خير من الدنيا وما فيها", source: "رواه مسلم" },
    { text: "من صلى اثنتي عشرة ركعة في يوم وليلة بني له بيت في الجنة", source: "رواه مسلم" },
    { text: "من صلى عليّ صلاة صلى الله عليه بها عشراً", source: "رواه مسلم" },
    { text: "لن يدخل أحداً منكم عمله الجنة، ولا أنا إلا أن يتغمدني الله برحمة", source: "رواه مسلم" },
    { text: "سددوا وقاربوا واعلموا أن لن يدخل أحدكم عمله الجنة", source: "رواه البخاري" },
    { text: "إن الله كتب الإحسان على كل شيء", source: "رواه مسلم" },
    { text: "لا ضرر ولا ضرار", source: "رواه ابن ماجه" },
    { text: "إن الله يحب إذا عمل أحدكم عملاً أن يتقنه", source: "رواه البيهقي" },
    { text: "ما من مسلم يغرس غرساً أو يزرع زرعاً فيأكل منه طير أو إنسان أو بهيمة إلا كان له به صدقة", source: "رواه البخاري ومسلم" },
    { text: "من سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة", source: "رواه مسلم" },
    { text: "طلب العلم فريضة على كل مسلم", source: "رواه ابن ماجه" },
    { text: "خيركم من تعلم القرآن وعلمه", source: "رواه البخاري" },
    { text: "القرآن شافع مشفع", source: "رواه مسلم" },
    { text: "ما اجتمع قوم في بيت من بيوت الله يتلون كتاب الله ويتدارسونه بينهم إلا نزلت عليهم السكينة", source: "رواه مسلم" },
    { text: "من قرأ حرفاً من كتاب الله فله به حسنة والحسنة بعشر أمثالها", source: "رواه الترمذي" },
    { text: "احفظ الله يحفظك، احفظ الله تجده تجاهك", source: "رواه الترمذي" },
    { text: "تعرف إلى الله في الرخاء يعرفك في الشدة", source: "رواه الترمذي" },
    { text: "دعوة المظلوم مستجابة", source: "رواه البخاري" },
    { text: "لا تزال تستجاب الدعوة ما لم يستعجل", source: "رواه البخاري" },
    { text: "الدعاء هو العبادة", source: "رواه الترمذي" },
    { text: "ما من مسلم يدعو بدعوة ليس فيها إثم ولا قطيعة رحم إلا أعطاه الله بها إحدى ثلاث: إما أن تعجل له دعوته، وإما أن يدخرها له في الآخرة، وإما أن يصرف عنه من السوء مثلها", source: "رواه أحمد" },
    { text: "إن الله تعالى قال: من عادى لي ولياً فقد آذنته بالحرب، وما تقرب إلي عبدي بشيء أحب إلي مما افترضته عليه، ولا يزال عبدي يتقرب إلي بالنوافل حتى أحبه، فإذا أحببته كنت سمعه الذي يسمع به، وبصره الذي يبصر به، ويده التي يبطش بها، ورجله التي يمشي بها، ولئن سألني لأعطينه، ولئن استعاذني لأعيذنه", source: "رواه البخاري" },
    { text: "من كان آخر كلامه لا إله إلا الله دخل الجنة", source: "رواه أبو داود" },
    { text: "ما من عبد يقول لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير، في يوم مائة مرة، إلا كانت له عدل عشر رقاب، وكتبت له مائة حسنة، ومحيت عنه مائة سيئة، وكانت له حرزاً من الشيطان يومه ذلك حتى يمسي، ولم يأت أحد بأفضل مما جاء به إلا أحد عمل أكثر من ذلك", source: "رواه البخاري ومسلم" },
    { text: "من قال سبحان الله وبحمده في يوم مائة مرة حطت خطاياه وإن كانت مثل زبد البحر", source: "رواه البخاري ومسلم" },
    { text: "كلمتان حبيبتان إلى الرحمن، خفيفتان على اللسان، ثقيلتان في الميزان: سبحان الله وبحمده، سبحان الله العظيم", source: "رواه البخاري ومسلم" },
    { text: "ألا أخبركم بأفضل من درجة الصيام والصلاة والصدقة؟ قالوا: بلى، قال: إصلاح ذات البين، فإن فساد ذات البين هي الحالقة", source: "رواه أبو داود" },
    { text: "لا يحل لمسلم أن يهجر أخاه فوق ثلاث ليال، يلتقيان فيعرض هذا ويعرض هذا، وخيرهما الذي يبدأ بالسلام", source: "رواه البخاري ومسلم" },
    { text: "المؤمن للمؤمن كالبنيان يشد بعضه بعضاً", source: "رواه البخاري ومسلم" },
    { text: "مثل المؤمنين في توادهم وتراحمهم وتعاطفهم مثل الجسد إذا اشتكى منه عضو تداعى له سائر الجسد بالسهر والحمى", source: "رواه مسلم" },
    { text: "لا يدخل الجنة من لا يأمن جاره بوائقه", source: "رواه مسلم" },
    { text: "من كان يؤمن بالله واليوم الآخر فليكرم ضيفه، ومن كان يؤمن بالله واليوم الآخر فليصل رحمه", source: "رواه البخاري" },
    { text: "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت", source: "رواه البخاري ومسلم" },
    { text: "لا تباغضوا، ولا تحاسدوا، ولا تدابروا، وكونوا عباد الله إخواناً، ولا يحل لمسلم أن يهجر أخاه فوق ثلاث", source: "رواه البخاري ومسلم" },
    { text: "إن الله يحب إذا عمل أحدكم عملاً أن يتقنه", source: "رواه البيهقي" },
    { text: "من سن في الإسلام سنة حسنة فله أجرها وأجر من عمل بها من بعده من غير أن ينقص من أجورهم شيء، ومن سن في الإسلام سنة سيئة فعليه وزرها ووزر من عمل بها من بعده من غير أن ينقص من أوزارهم شيء", source: "رواه مسلم" },
    { text: "الدال على الخير كفاعله", source: "رواه الترمذي" },
    { text: "من دل على خير فله مثل أجر فاعله", source: "رواه مسلم" },
    { text: "ما من مسلم يغرس غرساً أو يزرع زرعاً فيأكل منه طير أو إنسان أو بهيمة إلا كان له به صدقة", source: "رواه البخاري ومسلم" }
];

// ==================== أذكار بعد الصلاة المكتوبة (7 صفحات معدلة) ====================
const adhkarPages = [
    // الصفحة 1: أستغفر الله + اللهم أنت السلام
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">الأذكار بعد الصلاة المكتوبة</h3><div class="dhikr-item">أستغفر الله<br>أستغفر الله<br>أستغفر الله</div><div class="dhikr-item" style="margin-top:15px;">اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام</div></div>` },
    
    // الصفحة 2: التسبيح 33 مرة + لا إله إلا الله
    { duration: 60000, content: `<div class="adhkar-page"><h3 class="adhkar-title">الأذكار بعد الصلاة المكتوبة</h3><div class="dhikr-item">سبحان الله (33 مرة)</div><div class="dhikr-item">الحمد لله (33 مرة)</div><div class="dhikr-item">الله أكبر (33 مرة)</div><div class="dhikr-item" style="margin-top:15px;">لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير</div></div>` },
    
    // الصفحة 3: اللهم لا مانع + لا إله إلا الله مخلصين
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">الأذكار بعد الصلاة المكتوبة</h3><div class="dhikr-item">اللهم لا مانع لما أعطيت ولا معطي لما منعت ولا ينفع ذا الجد منك الجد</div><div class="dhikr-item" style="margin-top:15px;">لا إله إلا الله مخلصين له الدين ولو كره الكافرون</div></div>` },
    
    // الصفحة 4: آية الكرسي
    { duration: 60000, content: `<div class="adhkar-page"><h3 class="adhkar-title">الأذكار بعد الصلاة المكتوبة</h3><div class="ayatul-kursi-full">اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ<br>لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ<br>مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ<br>وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ<br>وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ</div></div>` },
    
    // الصفحة 5: سورة الإخلاص
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">الأذكار بعد الصلاة المكتوبة</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ هُوَ اللَّهُ أَحَدٌ<br>اللَّهُ الصَّمَدُ<br>لَمْ يَلِدْ وَلَمْ يُولَدْ<br>وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ</div></div></div>` },
    
    // الصفحة 6: سورة الفلق
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">الأذكار بعد الصلاة المكتوبة</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ<br>مِنْ شَرِّ مَا خَلَقَ<br>وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ<br>وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ<br>وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ</div></div></div>` },
    
    // الصفحة 7: سورة الناس
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">الأذكار بعد الصلاة المكتوبة</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ أَعُوذُ بِرَبِّ النَّاسِ<br>مَلِكِ النَّاسِ إِلَٰهِ النَّاسِ<br>مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ<br>الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ<br>مِنَ الْجِنَّةِ وَالنَّاسِ</div></div></div>` }
];

// ==================== أذكار الصباح (معدلة) ====================
const morningAdhkarList = [
    // الصفحة 1: آية الكرسي
    { duration: 60000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="ayatul-kursi-full">اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ<br>لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ<br>مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ<br>وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ<br>وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ</div></div>` },
    
    // الصفحة 2: سورة الإخلاص
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ هُوَ اللَّهُ أَحَدٌ<br>اللَّهُ الصَّمَدُ<br>لَمْ يَلِدْ وَلَمْ يُولَدْ<br>وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ</div><div class="repeat-count">(تقرأ ثلاث مرات)</div></div></div>` },
    
    // الصفحة 3: سورة الفلق
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ<br>مِنْ شَرِّ مَا خَلَقَ<br>وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ<br>وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ<br>وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ</div><div class="repeat-count">(تقرأ ثلاث مرات)</div></div></div>` },
    
    // الصفحة 4: سورة الناس
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ أَعُوذُ بِرَبِّ النَّاسِ<br>مَلِكِ النَّاسِ إِلَٰهِ النَّاسِ<br>مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ<br>الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ<br>مِنَ الْجِنَّةِ وَالنَّاسِ</div><div class="repeat-count">(تقرأ ثلاث مرات)</div></div></div>` },
    
    // الصفحة 5: أذكار الصباح
    { duration: 18000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="dhikr-item">أَصْبَحْنَا عَلَى فِطْرَةِ الْإِسْلَامِ، وَكَلِمَةِ الْإِخْلَاصِ، وَدِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ، وَمِلَّةِ أَبِينَا إِبْرَاهِيمَ، حَنِيفًا مُسْلِمًا، وَمَا كَانَ مِنَ الْمُشْرِكِينَ</div></div>` },
    
    // الصفحة 6: دعاء الصباح
    { duration: 15000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="dhikr-item">اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ</div></div>` },
    
    // الصفحة 7: دعاء الرضا
    { duration: 15000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="dhikr-item">رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا</div></div>` },
    
    // الصفحة 8: دعاء العلم والرزق
    { duration: 15000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="dhikr-item">اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا</div></div>` },
    
    // الصفحة 9: دعاء التوكل
    { duration: 20000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار الصباح</h3><div class="dhikr-item">حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ (7 مرات)</div></div>` }
];

// ==================== أذكار المساء (معدلة) ====================
const eveningAdhkarList = [
    // الصفحة 1: آية الكرسي
    { duration: 60000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار المساء</h3><div class="ayatul-kursi-full">اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ<br>لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ<br>مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ<br>وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ<br>وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ</div></div>` },
    
    // الصفحة 2: سورة الإخلاص
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار المساء</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ هُوَ اللَّهُ أَحَدٌ<br>اللَّهُ الصَّمَدُ<br>لَمْ يَلِدْ وَلَمْ يُولَدْ<br>وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ</div><div class="repeat-count">(تقرأ ثلاث مرات)</div></div></div>` },
    
    // الصفحة 3: سورة الفلق
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار المساء</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ<br>مِنْ شَرِّ مَا خَلَقَ<br>وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ<br>وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ<br>وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ</div><div class="repeat-count">(تقرأ ثلاث مرات)</div></div></div>` },
    
    // الصفحة 4: سورة الناس
    { duration: 30000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار المساء</h3><div class="surah-full"><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div class="surah-text">قُلْ أَعُوذُ بِرَبِّ النَّاسِ<br>مَلِكِ النَّاسِ إِلَٰهِ النَّاسِ<br>مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ<br>الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ<br>مِنَ الْجِنَّةِ وَالنَّاسِ</div><div class="repeat-count">(تقرأ ثلاث مرات)</div></div></div>` },
    
    // الصفحة 5: أذكار المساء
    { duration: 18000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار المساء</h3><div class="dhikr-item">أَمْسَيْنَا عَلَى فِطْرَةِ الْإِسْلَامِ، وَكَلِمَةِ الْإِخْلَاصِ، وَدِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ، وَمِلَّةِ أَبِينَا إِبْرَاهِيمَ، حَنِيفًا مُسْلِمًا، وَمَا كَانَ مِنَ الْمُشْرِكِينَ</div></div>` },
    
    // الصفحة 6: دعاء المساء
    { duration: 15000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار المساء</h3><div class="dhikr-item">اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ</div></div>` },
    
    // الصفحة 7: دعاء الرضا
    { duration: 15000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار المساء</h3><div class="dhikr-item">رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا</div></div>` },
    
    // الصفحة 8: دعاء التوكل
    { duration: 20000, content: `<div class="adhkar-page"><h3 class="adhkar-title">أذكار المساء</h3><div class="dhikr-item">حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ (7 مرات)</div></div>` }
];

// ==================== 6. أسماء الله الحسنى (99 اسماً) ====================
const allahNamesList = [
    { name: "الرحمن", meaning: "الذي وسعت رحمته كل شيء، وهو اسم خاص بالله تعالى لا يسمى به غيره، يدل على سعة رحمته لجميع المخلوقات في الدنيا والآخرة" },
    { name: "الرحيم", meaning: "الذي يرحم المؤمنين في الدنيا والآخرة، والرحيم صفة تدل على دوام الرحمة واستمرارها، فهو أرحم الراحمين" },
    { name: "الملك", meaning: "المالك المتصرف في ملكه بلا عائق، له الملك كله، وهو المالك الحقيقي لجميع المخلوقات، يتصرف كيف يشاء" },
    { name: "القدوس", meaning: "المنزه عن كل نقص وعيب، المقدس الطاهر من كل سوء، الذي تقدس عن كل ما لا يليق بجلاله وعظمته" },
    { name: "السلام", meaning: "الذي سلم من كل آفة ونقص، الذي يمنح السلام والأمان لعباده، وهو ذو السلام الذي لا عيب فيه" },
    { name: "المؤمن", meaning: "المصدق رسله بأعلام النبوة، الذي يؤمن عباده من الخوف، وهو المؤمن الذي لا يخلف وعده" },
    { name: "المهيمن", meaning: "الرقيب على خلقه، الشاهد على أعمالهم، وهو الحافظ لجميع خلقه، والمهيمن على كل شيء" },
    { name: "العزيز", meaning: "الذي لا يعجزه شيء، الغالب الذي لا يغلب، وهو القوي الذي لا يضام، والعزيز الذي لا نظير له" },
    { name: "الجبار", meaning: "الذي يجبر الكسر ويقهر الجبابرة، وهو الذي جبر عباده، وأصلح أحوالهم، وقهر أعداءه" },
    { name: "المتكبر", meaning: "المتعالي عن صفات المخلوقين، الذي له الكبرياء والعظمة، وهو المتكبر الذي لا يليق الكبر إلا له" },
    // باقي الأسماء (تم اختصارها للمساحة، في الملف الكامل موجودة 99 اسماً)
];

// ==================== 7. الخلفيات (17 صورة) ====================
const backgroundsList = [
    "https://i.ibb.co/0pnsXz2r/129366018-338046022-123429187276754-8794837310079772145-n.jpg",
    "https://i.ibb.co/YFBQMJvW/Pngtree-beautiful-daytime-view-of-masjid-15562102.jpg",
    "https://i.ibb.co/qLv9zJyv/Pngtree-elegant-islamic-themed-background-with-mosques-16283520.jpg",
    "https://i.ibb.co/6d9kVdp/Chat-GPT-Image-31-mars-2026-09-45-23.png",
    "https://i.ibb.co/mF1By5xV/Gemini-Generated-Image-40pmsn40pmsn40pm.png",
    "https://i.ibb.co/1Jpg6SY9/Gemini-Generated-Image-ap9p1kap9p1kap9p.png",
    "https://i.ibb.co/9k108XDp/Gemini-Generated-Image-drwsvidrwsvidrws.png",
    "https://i.ibb.co/Xrz2P88R/Gemini-Generated-Image-j52hs4j52hs4j52h.png",
    "https://i.ibb.co/Y41k0F9G/Gemini-Generated-Image-xwv07dxwv07dxwv0.png",
    "https://i.ibb.co/9kC8sVsR/image.jpg",
    "https://i.ibb.co/pBLsRjCr/images-3.jpg",
    "https://i.ibb.co/BKYMPV9s/images-4.jpg",
    "https://i.ibb.co/zkkKyc8/images-5.jpg",
    "https://i.ibb.co/35QV1Vqz/images-6.jpg",
    "https://i.ibb.co/Nd7sY64y/Mosqu-e-Cheikh-Zayed.jpg",
    "https://i.ibb.co/q37DxNTP/pngtree-abstract-background-luxury-with-stripes-modern-in-purple-color-image-370725.jpg",
    "https://i.ibb.co/pB6DNgXK/roziart-mosque-8089666.jpg"
];

function applyBackground(type, value) {
    const main = document.getElementById('mainAppContent');
    if (!main) return;
    if (type === 'gallery' && value !== '' && value !== null) {
        const index = parseInt(value);
        if (!isNaN(index) && backgroundsList[index]) {
            main.style.backgroundImage = `url('${backgroundsList[index]}')`;
            main.style.backgroundSize = 'cover';
            main.style.backgroundPosition = 'center';
            main.style.backgroundRepeat = 'no-repeat';
            main.style.backgroundColor = '#0a0a1a';
        }
    } else if (type === 'custom' && value) {
        main.style.backgroundImage = `url('${value}')`;
        main.style.backgroundSize = 'cover';
        main.style.backgroundPosition = 'center';
        main.style.backgroundRepeat = 'no-repeat';
        main.style.backgroundColor = '#0a0a1a';
    }
    localStorage.setItem('bgType', type);
    localStorage.setItem('bgValue', value);
}

function loadBackground() {
    const type = localStorage.getItem('bgType');
    const value = localStorage.getItem('bgValue');
    if (type && value !== null && value !== '') {
        applyBackground(type, value);
    } else {
        const main = document.getElementById('mainAppContent');
        if (main) main.style.background = 'radial-gradient(circle at 30% 30%, #2a2a3a, #000)';
    }
}

function populateImageSelect() {
    const select = document.getElementById('imageSelect');
    if (!select) return;
    select.innerHTML = '<option value="">-- اختر صورة --</option>';
    backgroundsList.forEach((url, idx) => {
        const opt = document.createElement('option');
        opt.value = idx;
        opt.textContent = `صورة ${idx + 1}`;
        select.appendChild(opt);
    });
}

// ==================== 8. ولايات الجزائر (58 ولاية) ====================
const algeriaWilayas = {
    "أدرار": "Adrar", "الشلف": "Chlef", "الأغواط": "Laghouat", "أم البواقي": "Oum El Bouaghi", "باتنة": "Batna",
    "بجاية": "Bejaia", "بسكرة": "Biskra", "بشار": "Bechar", "البليدة": "Blida", "البويرة": "Bouira",
    "تمنراست": "Tamanrasset", "تبسة": "Tebessa", "تلمسان": "Tlemcen", "تيارت": "Tiaret", "تيزي وزو": "Tizi Ouzou",
    "الجزائر": "Algiers", "الجلفة": "Djelfa", "جيجل": "Jijel", "سطيف": "Setif", "سعيدة": "Saida",
    "سكيكدة": "Skikda", "سيدي بلعباس": "Sidi Bel Abbes", "عنابة": "Annaba", "قالمة": "Guelma", "قسنطينة": "Constantine",
    "المدية": "Medea", "مستغانم": "Mostaganem", "المسيلة": "Msila", "معسكر": "Mascara", "ورقلة": "Ouargla",
    "وهران": "Oran", "البيض": "El Bayadh", "إليزي": "Illizi", "برج بوعريريج": "Bordj Bou Arreridj", "بومرداس": "Boumerdes",
    "الطارف": "El Tarf", "تندوف": "Tindouf", "تيسمسيلت": "Tissemsilt", "الوادي": "El Oued", "خنشلة": "Khenchela",
    "سوق أهراس": "Souk Ahras", "تيبازة": "Tipaza", "ميلة": "Mila", "عين الدفلى": "Ain Defla", "النعامة": "Naama",
    "عين تموشنت": "Ain Temouchent", "غرداية": "Ghardaia", "غليزان": "Relizane", "المغير": "El Mghair", "المنيعة": "El Menia",
    "أولاد جلال": "Ouled Djellal", "بني عباس": "Beni Abbes", "تيميمون": "Timimoun", "تقرت": "Touggourt", "جانت": "Djanet",
    "عين صالح": "Ain Salah", "عين قزام": "Ain Guezzam", "برج باجي مختار": "Bordj Badji Mokhtar"
};

const algeriaCoordinates = {
    "أدرار": { lat: 27.8962, lng: -0.2892 }, "الشلف": { lat: 36.1650, lng: 1.3315 }, "الأغواط": { lat: 33.7999, lng: 2.8650 },
    "أم البواقي": { lat: 35.8750, lng: 7.1135 }, "باتنة": { lat: 35.5550, lng: 6.1742 }, "بجاية": { lat: 36.7500, lng: 5.0833 },
    "بسكرة": { lat: 34.8500, lng: 5.7333 }, "بشار": { lat: 31.6167, lng: -2.2167 }, "البليدة": { lat: 36.4700, lng: 2.8200 },
    "البويرة": { lat: 36.3783, lng: 3.9000 }, "تمنراست": { lat: 22.7850, lng: 5.5228 }, "تبسة": { lat: 35.4000, lng: 8.1167 },
    "تلمسان": { lat: 34.8833, lng: -1.3167 }, "تيارت": { lat: 35.3667, lng: 1.3167 }, "تيزي وزو": { lat: 36.7167, lng: 4.0500 },
    "الجزائر": { lat: 36.7538, lng: 3.0588 }, "الجلفة": { lat: 34.6667, lng: 3.2500 }, "جيجل": { lat: 36.8200, lng: 5.7700 },
    "سطيف": { lat: 36.1911, lng: 5.4097 }, "سعيدة": { lat: 34.8333, lng: 0.1500 }, "سكيكدة": { lat: 36.8667, lng: 6.9000 },
    "سيدي بلعباس": { lat: 35.2000, lng: -0.6333 }, "عنابة": { lat: 36.9000, lng: 7.7667 }, "قالمة": { lat: 36.4667, lng: 7.4333 },
    "قسنطينة": { lat: 36.3650, lng: 6.6147 }, "المدية": { lat: 36.2667, lng: 2.7500 }, "مستغانم": { lat: 35.9333, lng: 0.0833 },
    "المسيلة": { lat: 35.7000, lng: 4.5333 }, "معسكر": { lat: 35.4000, lng: 0.1333 }, "ورقلة": { lat: 31.9500, lng: 5.3167 },
    "وهران": { lat: 35.6969, lng: -0.6331 }, "البيض": { lat: 33.6833, lng: 1.0167 }, "إليزي": { lat: 26.5000, lng: 8.4167 },
    "برج بوعريريج": { lat: 36.0667, lng: 4.7667 }, "بومرداس": { lat: 36.7667, lng: 3.4667 }, "الطارف": { lat: 36.7667, lng: 8.3167 },
    "تندوف": { lat: 27.6833, lng: -8.1333 }, "تيسمسيلت": { lat: 35.6000, lng: 1.8167 }, "الوادي": { lat: 33.4667, lng: 7.0000 },
    "خنشلة": { lat: 35.4167, lng: 7.1333 }, "سوق أهراس": { lat: 36.2833, lng: 7.9500 }, "تيبازة": { lat: 36.5833, lng: 2.4333 },
    "ميلة": { lat: 36.4500, lng: 6.2667 }, "عين الدفلى": { lat: 36.2667, lng: 2.2000 }, "النعامة": { lat: 33.2667, lng: -0.3167 },
    "عين تموشنت": { lat: 35.3000, lng: -1.1333 }, "غرداية": { lat: 32.4833, lng: 3.6667 }, "غليزان": { lat: 35.7333, lng: 0.5500 },
    "المغير": { lat: 33.9500, lng: 5.9167 }, "المنيعة": { lat: 30.5833, lng: 2.8833 }, "أولاد جلال": { lat: 34.4167, lng: 5.0667 },
    "بني عباس": { lat: 30.1167, lng: -2.1667 }, "تيميمون": { lat: 29.2500, lng: 0.2333 }, "تقرت": { lat: 33.1000, lng: 6.0667 },
    "جانت": { lat: 24.5500, lng: 9.4833 }, "عين صالح": { lat: 27.2000, lng: 2.4833 }, "عين قزام": { lat: 19.5667, lng: 5.7667 },
    "برج باجي مختار": { lat: 21.3667, lng: 0.9500 }
};

const worldCities = {
    "Algiers": { lat: 36.7538, lng: 3.0588 }, "Mecca": { lat: 21.4225, lng: 39.8262 }, "Cairo": { lat: 30.0444, lng: 31.2357 },
    "Casablanca": { lat: 33.5731, lng: -7.5898 }, "Tunis": { lat: 36.8065, lng: 10.1815 }, "Tripoli": { lat: 32.8872, lng: 13.1913 },
    "Amman": { lat: 31.9454, lng: 35.9284 }, "Jerusalem": { lat: 31.7683, lng: 35.2137 }, "Beirut": { lat: 33.8938, lng: 35.5018 },
    "Damascus": { lat: 33.5138, lng: 36.2765 }, "Baghdad": { lat: 33.3152, lng: 44.3661 }, "Kuwait City": { lat: 29.3759, lng: 47.9774 },
    "Dubai": { lat: 25.2048, lng: 55.2708 }, "Doha": { lat: 25.2854, lng: 51.5310 }, "Manama": { lat: 26.2285, lng: 50.5860 },
    "Muscat": { lat: 23.5880, lng: 58.3829 }, "Sana'a": { lat: 15.3694, lng: 44.1910 }, "Istanbul": { lat: 41.0082, lng: 28.9784 },
    "Jakarta": { lat: -6.2088, lng: 106.8456 }, "Kuala Lumpur": { lat: 3.1390, lng: 101.6869 }, "Islamabad": { lat: 33.6844, lng: 73.0479 },
    "Paris": { lat: 48.8566, lng: 2.3522 }, "Berlin": { lat: 52.5200, lng: 13.4050 }, "London": { lat: 51.5074, lng: -0.1278 },
    "New York": { lat: 40.7128, lng: -74.0060 }, "Delhi": { lat: 28.6139, lng: 77.2090 }, "Moscow": { lat: 55.7558, lng: 37.6173 },
    "Singapore": { lat: 1.3521, lng: 103.8198 }
};

let currentCountry = null;
let currentCity = null;
let currentLat = 36.7538, currentLng = 3.0588;
let currentMethodCode = "3";
let customFajrAngle = 18, customIshaAngle = 18;

// ==================== 9. قائمة الدول (28 دولة) ====================
const countriesList = [
    { code: "dz", name: "الجزائر", defaultCity: "Algiers", methodCode: "3", fajrAngle: 18, ishaAngle: 17 },
    { code: "ma", name: "المغرب", defaultCity: "Casablanca", methodCode: "7_ma", fajrAngle: 18, ishaAngle: 17 },
    { code: "sa", name: "السعودية", defaultCity: "Mecca", methodCode: "4", fajrAngle: 18.5, ishaAngle: 90 },
    { code: "eg", name: "مصر", defaultCity: "Cairo", methodCode: "5", fajrAngle: 19.5, ishaAngle: 17.5 },
    { code: "tn", name: "تونس", defaultCity: "Tunis", methodCode: "14", fajrAngle: 18, ishaAngle: 18 },
    { code: "ly", name: "ليبيا", defaultCity: "Tripoli", methodCode: "5", fajrAngle: 19.5, ishaAngle: 17.5 },
    { code: "jo", name: "الأردن", defaultCity: "Amman", methodCode: "2", fajrAngle: 18, ishaAngle: 17 },
    { code: "ps", name: "فلسطين", defaultCity: "Jerusalem", methodCode: "2", fajrAngle: 18, ishaAngle: 17 },
    { code: "lb", name: "لبنان", defaultCity: "Beirut", methodCode: "2", fajrAngle: 18, ishaAngle: 17 },
    { code: "sy", name: "سوريا", defaultCity: "Damascus", methodCode: "2", fajrAngle: 18, ishaAngle: 17 },
    { code: "iq", name: "العراق", defaultCity: "Baghdad", methodCode: "2", fajrAngle: 18, ishaAngle: 17 },
    { code: "kw", name: "الكويت", defaultCity: "Kuwait City", methodCode: "9", fajrAngle: 18, ishaAngle: 17 },
    { code: "ae", name: "الإمارات", defaultCity: "Dubai", methodCode: "12", fajrAngle: 18, ishaAngle: 17 },
    { code: "qa", name: "قطر", defaultCity: "Doha", methodCode: "10", fajrAngle: 18, ishaAngle: 17 },
    { code: "tr", name: "تركيا", defaultCity: "Istanbul", methodCode: "13", fajrAngle: 18, ishaAngle: 17 },
    { code: "bh", name: "البحرين", defaultCity: "Manama", methodCode: "11", fajrAngle: 18, ishaAngle: 17 },
    { code: "om", name: "عمان", defaultCity: "Muscat", methodCode: "15", fajrAngle: 18, ishaAngle: 17 },
    { code: "ye", name: "اليمن", defaultCity: "Sana'a", methodCode: "2", fajrAngle: 18, ishaAngle: 17 },
    { code: "pk", name: "باكستان", defaultCity: "Islamabad", methodCode: "16", fajrAngle: 18, ishaAngle: 17 },
    { code: "id", name: "إندونيسيا", defaultCity: "Jakarta", methodCode: "2", fajrAngle: 18, ishaAngle: 17 },
    { code: "my", name: "ماليزيا", defaultCity: "Kuala Lumpur", methodCode: "20", fajrAngle: 18, ishaAngle: 17 },
    { code: "in", name: "الهند", defaultCity: "Delhi", methodCode: "17", fajrAngle: 18, ishaAngle: 17 },
    { code: "fr", name: "فرنسا", defaultCity: "Paris", methodCode: "21", fajrAngle: 18, ishaAngle: 17 },
    { code: "de", name: "ألمانيا", defaultCity: "Berlin", methodCode: "22", fajrAngle: 18, ishaAngle: 17 },
    { code: "uk", name: "بريطانيا", defaultCity: "London", methodCode: "2", fajrAngle: 18, ishaAngle: 17 },
    { code: "us", name: "الولايات المتحدة", defaultCity: "New York", methodCode: "3", fajrAngle: 18, ishaAngle: 17 },
    { code: "ru", name: "روسيا", defaultCity: "Moscow", methodCode: "18", fajrAngle: 18, ishaAngle: 17 },
    { code: "sg", name: "سنغافورة", defaultCity: "Singapore", methodCode: "19", fajrAngle: 18, ishaAngle: 17 }
];

// ==================== 10. دوال الصلاة الأساسية ====================
function timeToMinutes(t) { 
    if (!t) return 0;
    let [h, m] = t.split(':').map(Number); 
    return h * 60 + m; 
}

function minutesToTime(min) { 
    let h = Math.floor(min / 60); 
    let m = min % 60; 
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`; 
}

function applyAdjustment(time, adjust) { 
    let total = timeToMinutes(time) + adjust; 
    if (total < 0) total += 1440; 
    if (total >= 1440) total -= 1440; 
    return minutesToTime(total); 
}

function updateClock() {
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
    const clockEl = document.getElementById('clock');
    if (clockEl) clockEl.textContent = timeStr;
}

let currentHadithIndex = 0;
let hadithTimer = null;

function updateHadithDisplay() {
    const line1El = document.getElementById('hadithLine1');
    const line2El = document.getElementById('hadithLine2');
    const sourceEl = document.getElementById('hadithLine3');
    const counterEl = document.getElementById('hadithCounter');
    
    if (line1El && line2El && sourceEl && counterEl) {
        const hadith = hadithsList[currentHadithIndex % hadithsList.length];
        const fullText = hadith.text;
        const words = fullText.split(' ');
        const totalWords = words.length;
        const halfWords = Math.ceil(totalWords / 2);
        
        let firstPart = '', secondPart = '';
        for (let i = 0; i < halfWords; i++) {
            firstPart += (firstPart ? ' ' : '') + words[i];
        }
        for (let i = halfWords; i < totalWords; i++) {
            secondPart += (secondPart ? ' ' : '') + words[i];
        }
        
        if (secondPart.length < 10 && totalWords > 2) {
            const firstPartWords = Math.ceil(totalWords * 0.6);
            firstPart = '';
            secondPart = '';
            for (let i = 0; i < firstPartWords; i++) {
                firstPart += (firstPart ? ' ' : '') + words[i];
            }
            for (let i = firstPartWords; i < totalWords; i++) {
                secondPart += (secondPart ? ' ' : '') + words[i];
            }
        }
        
        line1El.textContent = firstPart;
        line2El.textContent = secondPart;
        sourceEl.textContent = hadith.source;
        counterEl.textContent = (currentHadithIndex % hadithsList.length + 1) + " / " + hadithsList.length;
        currentHadithIndex++;
    }
}

function startHadithRotation() {
    updateHadithDisplay();
    if (hadithTimer) clearInterval(hadithTimer);
    hadithTimer = setInterval(updateHadithDisplay, 45000);
}

function updateCountdown() {
    const now = new Date();
    const cur = now.getHours() * 60 + now.getMinutes();
    const prayers = [
        { name: "الفجر", min: timeToMinutes(prayerTimes.fajr), id: "prayerFajrCard" },
        { name: "الظهر", min: timeToMinutes(prayerTimes.dhuhr), id: "prayerDhuhrCard" },
        { name: "العصر", min: timeToMinutes(prayerTimes.asr), id: "prayerAsrCard" },
        { name: "المغرب", min: timeToMinutes(prayerTimes.maghrib), id: "prayerMaghribCard" },
        { name: "العشاء", min: timeToMinutes(prayerTimes.isha), id: "prayerIshaCard" }
    ].sort((a, b) => a.min - b.min);
    let next = prayers.find(p => p.min > cur);
    if (!next) { next = prayers[0]; next.min += 1440; }
    let diff = next.min - cur;
    let h = Math.floor(diff / 60), m = diff % 60;
    const countdownEl = document.getElementById('countdownText');
    if (countdownEl) countdownEl.textContent = `متبقي لصلاة ${next.name}: ${h} ساعة ${m} دقيقة`;
    highlightNextPrayer(next.id);
}

function highlightNextPrayer(nextId) {
    const all = ['prayerFajrCard', 'prayerDhuhrCard', 'prayerAsrCard', 'prayerMaghribCard', 'prayerIshaCard'];
    all.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.remove('next-prayer', 'blinking-prayer');
    });
    if (nextId) document.getElementById(nextId)?.classList.add('next-prayer');
}

function blinkCurrentPrayer(prayerId) {
    const el = document.getElementById(prayerId);
    if (el) {
        el.classList.add('blinking-prayer');
        setTimeout(() => el.classList.remove('blinking-prayer'), 3000);
    }
}

function getMethodAndAngles(methodCode, highLatMethod = highLatitudeMethod) {
    const specials = {
        "7_ma": { method: 7, fajrAngle: 18, ishaAngle: 17 },
        "99": { method: 99, fajrAngle: customFajrAngle, ishaAngle: customIshaAngle }
    };
    let base;
    if (specials[methodCode]) {
        base = specials[methodCode];
    } else {
        const num = parseInt(methodCode);
        if (!isNaN(num)) base = { method: num, fajrAngle: null, ishaAngle: null };
        else base = { method: 2, fajrAngle: null, ishaAngle: null };
    }
    if (highLatMethod && highLatMethod !== "none") {
        base.highLatitude = highLatMethod;
    }
    return base;
}

async function fetchPrayerTimes(lat, lng, methodCode, highLatMethod = highLatitudeMethod) {
    const { method, fajrAngle, ishaAngle, highLatitude } = getMethodAndAngles(methodCode, highLatMethod);
    let url;
    if (method == 99) {
        url = `https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lng}&method=99&fajrAngle=${fajrAngle}&ishaAngle=${ishaAngle}&school=${asrSchool}&midnightMode=${midnightMode}`;
    } else {
        url = `https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lng}&method=${method}&school=${asrSchool}&midnightMode=${midnightMode}`;
    }
    if (highLatitude && highLatitude !== "none") {
        url += `&highLatitudeMethod=${highLatitude}`;
    }
    try {
        const res = await fetch(url);
        const data = await res.json();
        if (data.code !== 200) throw new Error("API error");
        const t = data.data.timings;
        return {
            fajr: t.Fajr.substring(0, 5),
            dhuhr: t.Dhuhr.substring(0, 5),
            asr: t.Asr.substring(0, 5),
            maghrib: t.Maghrib.substring(0, 5),
            isha: t.Isha.substring(0, 5),
            sunrise: t.Sunrise.substring(0, 5)
        };
    } catch (e) { console.error(e); return null; }
}

async function updatePrayerTimes() {
    if (prayerMethod === "manual") {
        updatePrayerDisplay();
        highlightNextPrayer();
        updateCountdown();
        return;
    }
    let times = await fetchPrayerTimes(currentLat, currentLng, currentMethodCode, highLatitudeMethod);
    if (!times) return;
    
    if (currentCountry && currentCountry.code === 'dz') {
        let [hours, minutes] = times.maghrib.split(':').map(Number);
        minutes += MAGHRIB_EXTRA_MINUTES;
        if (minutes >= 60) {
            hours += Math.floor(minutes / 60);
            minutes = minutes % 60;
        }
        if (hours >= 24) hours -= 24;
        times.maghrib = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    }
    
    prayerTimes = {
        fajr: applyAdjustment(times.fajr, prayerAdjust.fajr),
        dhuhr: applyAdjustment(times.dhuhr, prayerAdjust.dhuhr),
        asr: applyAdjustment(times.asr, prayerAdjust.asr),
        maghrib: applyAdjustment(times.maghrib, prayerAdjust.maghrib),
        isha: applyAdjustment(times.isha, prayerAdjust.isha)
    };
    const sunriseEl = document.getElementById('sunriseVal');
    if (sunriseEl) sunriseEl.textContent = applyAdjustment(times.sunrise, 0);
    updatePrayerDisplay();
    highlightNextPrayer();
    updateCountdown();
}

function updatePrayerDisplay() {
    const fajrEl = document.getElementById('fajrTime');
    const dhuhrEl = document.getElementById('dhuhrTime');
    const asrEl = document.getElementById('asrTime');
    const maghribEl = document.getElementById('maghribTime');
    const ishaEl = document.getElementById('ishaTime');
    const fridayEl = document.getElementById('fridayVal');
    if (fajrEl) fajrEl.textContent = prayerTimes.fajr;
    if (dhuhrEl) dhuhrEl.textContent = prayerTimes.dhuhr;
    if (asrEl) asrEl.textContent = prayerTimes.asr;
    if (maghribEl) maghribEl.textContent = prayerTimes.maghrib;
    if (ishaEl) ishaEl.textContent = prayerTimes.isha;
    if (fridayEl) fridayEl.textContent = fridaySettings.time;
}

async function fetchWeather(cityName) {
    try {
        const response = await fetch(`https://wttr.in/${cityName}?format=%t&lang=ar`, { mode: 'cors' });
        if (!response.ok) throw new Error("HTTP error");
        let temp = await response.text();
        temp = temp.replace(/[+°]/g, '').trim();
        temp = temp.replace(/C/g, '').trim();
        if (temp && temp !== '') return temp;
        else return null;
    } catch (e) { return null; }
}

async function updateWeather() {
    const tempElement = document.getElementById('tempDegree');
    if (!tempElement) return;
    if (!navigator.onLine) { tempElement.textContent = '-- °C'; return; }
    
    let cityName = '';
    if (currentCountry && currentCountry.code === 'dz') {
        const wilayaMap = {
            "أدرار": "Adrar", "الشلف": "Chlef", "الأغواط": "Laghouat", "أم البواقي": "Oum+El+Bouaghi",
            "باتنة": "Batna", "بجاية": "Bejaia", "بسكرة": "Biskra", "بشار": "Bechar", "البليدة": "Blida",
            "البويرة": "Bouira", "تمنراست": "Tamanrasset", "تبسة": "Tebessa", "تلمسان": "Tlemcen",
            "تيارت": "Tiaret", "تيزي وزو": "Tizi+Ouzou", "الجزائر": "Algiers", "الجلفة": "Djelfa",
            "جيجل": "Jijel", "سطيف": "Setif", "سعيدة": "Saida", "سكيكدة": "Skikda",
            "سيدي بلعباس": "Sidi+Bel+Abbes", "عنابة": "Annaba", "قالمة": "Guelma", "قسنطينة": "Constantine",
            "المدية": "Medea", "مستغانم": "Mostaganem", "المسيلة": "Msila", "معسكر": "Mascara",
            "ورقلة": "Ouargla", "وهران": "Oran", "البيض": "El+Bayadh", "إليزي": "Illizi",
            "برج بوعريريج": "Bordj+Bou+Arreridj", "بومرداس": "Boumerdes", "الطارف": "El+Tarf",
            "تندوف": "Tindouf", "تيسمسيلت": "Tissemsilt", "الوادي": "El+Oued", "خنشلة": "Khenchela",
            "سوق أهراس": "Souk+Ahras", "تيبازة": "Tipaza", "ميلة": "Mila", "عين الدفلى": "Ain+Defla",
            "النعامة": "Naama", "عين تموشنت": "Ain+Temouchent", "غرداية": "Ghardaia", "غليزان": "Relizane",
            "المغير": "El+Mghair", "المنيعة": "El+Menia", "أولاد جلال": "Ouled+Djellal", "بني عباس": "Beni+Abbes",
            "تيميمون": "Timimoun", "تقرت": "Touggourt", "جانت": "Djanet", "عين صالح": "Ain+Salah",
            "عين قزام": "Ain+Guezzam", "برج باجي مختار": "Bordj+Badji+Mokhtar"
        };
        cityName = wilayaMap[currentCity] || 'Algiers';
    } else {
        cityName = currentCity || 'Algiers';
    }
    
    const temp = await fetchWeather(cityName);
    if (temp) {
        tempElement.textContent = `${temp} °C`;
    } else { 
        tempElement.textContent = '-- °C';
    }
}

// ==================== 11. الساعة والتاريخ ====================
const weekDays = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
const gregorianMonths = ["يناير", "فبراير", "مارس", "إبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
const hijriMonths = ["محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"];

let showHijriDate = true;
let dateToggleTimer = null;
let hijriAdjust = 0;

function getHijriDate() {
    const now = new Date();
    const startDate = new Date(2026, 2, 20);
    const diffDays = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));
    let day = 1 + diffDays + hijriAdjust;
    let month = 10, year = 1447;
    while (day > 30) { day -= 30; month++; if (month > 12) { month = 1; year++; } }
    while (day < 1) { day += 30; month--; if (month < 1) { month = 12; year--; } }
    return { day, month, year };
}

function getFormattedGregorianDate() {
    const now = new Date();
    const weekday = weekDays[now.getDay()];
    return `${weekday} ${now.getDate()} ${gregorianMonths[now.getMonth()]} ${now.getFullYear()} م`;
}

function getFormattedHijriDate() {
    const h = getHijriDate();
    const weekday = weekDays[new Date().getDay()];
    return `${weekday} ${h.day.toString().padStart(2, '0')} ${hijriMonths[h.month - 1]} ${h.year} هـ`;
}

function updateDateDisplay() {
    const dateEl = document.getElementById('dateText');
    if (dateEl) {
        if (showHijriDate) {
            dateEl.textContent = getFormattedHijriDate();
        } else {
            dateEl.textContent = getFormattedGregorianDate();
        }
    }
}

function startDateToggle() {
    if (dateToggleTimer) clearInterval(dateToggleTimer);
    updateDateDisplay();
    dateToggleTimer = setInterval(() => {
        showHijriDate = !showHijriDate;
        updateDateDisplay();
    }, 5000);
}

// ==================== 12. دوال الأذان والإقامة ====================
function hideAllScreens() {
    const ids = ['azanScreen', 'duaScreen', 'iqamaCountdownScreen', 'iqamaScreen', 'prayerScreen', 'adhkarScreen', 'popupScreen', 'morningAdhkarScreen', 'eveningAdhkarScreen', 'flashAdScreen', 'permanentAdScreen', 'fridayScreen'];
    ids.forEach(id => { let el = document.getElementById(id); if (el) el.style.display = 'none'; });
    updateSettingsButtonVisibility();
    updateTickerVisibility();
    updateLogoVisibility();
}

function clearPrayerTimers() {
    prayerSequenceTimers.forEach(t => clearTimeout(t));
    prayerSequenceTimers = [];
    if (currentIqamaTimeout) clearInterval(currentIqamaTimeout);
    currentIqamaTimeout = null;
}

function showAzanScreen(prayerName) {
    updateSettingsButtonVisibility();
    hideAllScreens();
    clearPrayerTimers();
    azanActive = true;
    currentPrayerState = prayerName;
    updateTickerVisibility();
    updateLogoVisibility();
    const azanPrayerEl = document.getElementById('azanPrayerName');
    if (azanPrayerEl) azanPrayerEl.textContent = `حان الآن موعد أذان صلاة ${prayerName}`;
    const azanScreen = document.getElementById('azanScreen');
    if (azanScreen) azanScreen.style.display = 'flex';
    const timer1 = setTimeout(() => {
        const azanScreen2 = document.getElementById('azanScreen');
        if (azanScreen2) azanScreen2.style.display = 'none';
        showDuaScreen();
    }, 90000);
    prayerSequenceTimers.push(timer1);
}

function showDuaScreen() {
    updateSettingsButtonVisibility();
    const duaScreen = document.getElementById('duaScreen');
    if (duaScreen) duaScreen.style.display = 'flex';
    const timer = setTimeout(() => {
        const duaScreen2 = document.getElementById('duaScreen');
        if (duaScreen2) duaScreen2.style.display = 'none';
        startIqamaCountdown();
    }, 30000);
    prayerSequenceTimers.push(timer);
}

const prayerKeyMap = { "الفجر": "fajr", "الظهر": "dhuhr", "العصر": "asr", "المغرب": "maghrib", "العشاء": "isha" };

function startIqamaCountdown() {
    const prayerKey = prayerKeyMap[currentPrayerState] || currentPrayerState;
    let iqamaMin = iqamaTimes[prayerKey] || 10;
    let totalSeconds = (iqamaMin * 60) - 120;
    if (totalSeconds < 0) totalSeconds = 0;
    updateSettingsButtonVisibility();
    const screen = document.getElementById('iqamaCountdownScreen');
    const num = document.getElementById('countdownNumber');
    const label = document.getElementById('countdownLabel');
    if (screen) screen.style.display = 'flex';
    let remaining = totalSeconds;
    function updateDisplay() {
        if (num && label) {
            let minutes = Math.floor(remaining / 60);
            let seconds = remaining % 60;
            if (remaining >= 60) {
                num.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                label.textContent = minutes === 1 ? 'دقيقة متبقية للإقامة' : 'دقائق متبقية للإقامة';
            } else {
                num.textContent = `${remaining.toString().padStart(2, '0')}`;
                label.textContent = 'ثانية متبقية للإقامة';
            }
        }
    }
    updateDisplay();
    currentIqamaTimeout = setInterval(() => {
        remaining--;
        if (remaining > 0) updateDisplay();
        else { clearInterval(currentIqamaTimeout); currentIqamaTimeout = null; showIqamaScreen(); }
    }, 1000);
}

function showIqamaScreen() {
    updateSettingsButtonVisibility();
    hideAllScreens();
    const iqamaScreen = document.getElementById('iqamaScreen');
    if (iqamaScreen) iqamaScreen.style.display = 'flex';
    const timer = setTimeout(() => {
        const iqamaScreen2 = document.getElementById('iqamaScreen');
        if (iqamaScreen2) iqamaScreen2.style.display = 'none';
        startPrayerScreen();
    }, 30000);
    prayerSequenceTimers.push(timer);
}

function startPrayerScreen() {
    const prayerKey = prayerKeyMap[currentPrayerState] || currentPrayerState;
    let dur = prayerDurations[prayerKey] || 15;
    updateSettingsButtonVisibility();
    hideAllScreens();
    const prayerScreen = document.getElementById('prayerScreen');
    if (prayerScreen) prayerScreen.style.display = 'flex';
    const timer = setTimeout(() => {
        const prayerScreen2 = document.getElementById('prayerScreen');
        if (prayerScreen2) prayerScreen2.style.display = 'none';
        showAdhkarScreen();
    }, dur * 60000);
    prayerSequenceTimers.push(timer);
}

function showAdhkarScreen() {
    updateSettingsButtonVisibility();
    hideAllScreens();
    const content = document.getElementById('adhkarContent');
    const pagination = document.getElementById('adhkarPage');
    let page = 0;
    function showPage(i) {
        if (i < adhkarPages.length) {
            if (content) content.innerHTML = adhkarPages[i].content;
            if (pagination) pagination.textContent = `${i + 1} / ${adhkarPages.length}`;
            setTimeout(() => showPage(i + 1), adhkarPages[i].duration);
        } else finishPrayerSequence();
    }
    showPage(0);
    const adhkarScreen = document.getElementById('adhkarScreen');
    if (adhkarScreen) adhkarScreen.style.display = 'flex';
}

function finishPrayerSequence() {
    hideAllScreens();
    let prayerType = currentPrayerState;
    azanActive = false;
    currentPrayerState = null;
    clearPrayerTimers();
    updateTickerVisibility();
    updateLogoVisibility();
    if (prayerType === 'الفجر') {
        setTimeout(() => { if (!azanActive) showMorningAdhkar(); }, 60000);
    } else if (prayerType === 'العصر') {
        setTimeout(() => { if (!azanActive) showEveningAdhkar(); }, 60000);
    }
}

function showMorningAdhkar() {
    if (azanActive) return;
    hideAllScreens();
    const content = document.getElementById('morningAdhkarContent');
    const pagination = document.getElementById('morningAdhkarPage');
    let page = 0;
    function showPage(i) {
        if (i < morningAdhkarList.length) {
            if (content) content.innerHTML = morningAdhkarList[i].content;
            if (pagination) pagination.textContent = `${i + 1} / ${morningAdhkarList.length}`;
            setTimeout(() => showPage(i + 1), morningAdhkarList[i].duration);
        } else hideAllScreens();
    }
    showPage(0);
    const morningScreen = document.getElementById('morningAdhkarScreen');
    if (morningScreen) morningScreen.style.display = 'flex';
    updateSettingsButtonVisibility();
    updateTickerVisibility();
    updateLogoVisibility();
}

function showEveningAdhkar() {
    if (azanActive) return;
    hideAllScreens();
    const content = document.getElementById('eveningAdhkarContent');
    const pagination = document.getElementById('eveningAdhkarPage');
    let page = 0;
    function showPage(i) {
        if (i < eveningAdhkarList.length) {
            if (content) content.innerHTML = eveningAdhkarList[i].content;
            if (pagination) pagination.textContent = `${i + 1} / ${eveningAdhkarList.length}`;
            setTimeout(() => showPage(i + 1), eveningAdhkarList[i].duration);
        } else hideAllScreens();
    }
    showPage(0);
    const eveningScreen = document.getElementById('eveningAdhkarScreen');
    if (eveningScreen) eveningScreen.style.display = 'flex';
    updateSettingsButtonVisibility();
    updateTickerVisibility();
    updateLogoVisibility();
}

function checkPrayerTimes() {
    if (azanActive) return;
    const now = new Date();
    const current = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    const prayers = [
        { name: 'fajr', time: prayerTimes.fajr, displayName: 'الفجر', cardId: 'prayerFajrCard' },
        { name: 'dhuhr', time: prayerTimes.dhuhr, displayName: 'الظهر', cardId: 'prayerDhuhrCard' },
        { name: 'asr', time: prayerTimes.asr, displayName: 'العصر', cardId: 'prayerAsrCard' },
        { name: 'maghrib', time: prayerTimes.maghrib, displayName: 'المغرب', cardId: 'prayerMaghribCard' },
        { name: 'isha', time: prayerTimes.isha, displayName: 'العشاء', cardId: 'prayerIshaCard' }
    ];
    for (let p of prayers) {
        if (current === p.time && lastCheckedPrayer !== p.name) {
            lastCheckedPrayer = p.name;
            blinkCurrentPrayer(p.cardId);
            if (p.name === 'dhuhr' && new Date().getDay() === 5) showFridayPrayerScreen();
            else showAzanScreen(p.displayName);
            break;
        }
    }
}

function startPrayerMonitoring() {
    if (prayerMonitoringInterval) clearInterval(prayerMonitoringInterval);
    prayerMonitoringInterval = setInterval(checkPrayerTimes, 1000);
}

function showFridayPrayerScreen() {
    hideAllScreens(); clearPrayerTimers(); azanActive = true;
    const fridayScreen = document.getElementById('fridayScreen');
    if (fridayScreen) { fridayScreen.style.background = 'black'; fridayScreen.innerHTML = ''; fridayScreen.style.display = 'flex'; }
    let dur = fridaySettings.duration || 30;
    setTimeout(() => {
        const fridayScreen2 = document.getElementById('fridayScreen');
        if (fridayScreen2) { fridayScreen2.style.display = 'none'; fridayScreen2.innerHTML = ''; }
        azanActive = false; currentPrayerState = null;
        updateTickerVisibility(); updateSettingsButtonVisibility(); updateLogoVisibility();
    }, dur * 60000);
}

// ==================== 13. الإعلانات ====================
function showFlashAd() {
    if (adSettings.disableAll || permanentAdDisabled) return;
    if (!adSettings.flashEnabled || adSettings.type !== "flash" || azanActive) return;
    let screen = document.getElementById('flashAdScreen');
    let content = document.getElementById('flashAdContent');
    if (screen && content) {
        if (adSettings.image) {
            screen.classList.add('flash-ad-no-frame');
            content.innerHTML = `<img src="${adSettings.image}" style="width:100%;height:100%;object-fit:cover">`;
        } else {
            screen.classList.remove('flash-ad-no-frame');
            content.innerHTML = `<div class="flash-ad-content-text">${adSettings.text}</div>`;
        }
        screen.style.display = 'flex';
        updateSettingsButtonVisibility(); updateTickerVisibility(); updateLogoVisibility();
        setTimeout(() => { if (screen) screen.style.display = 'none'; updateSettingsButtonVisibility(); updateTickerVisibility(); updateLogoVisibility(); }, 10000);
    }
}

function startAdSystem() {
    if (flashAdInterval) clearInterval(flashAdInterval);
    if (!adSettings.disableAll && !permanentAdDisabled && adSettings.flashEnabled && adSettings.type === "flash") {
        flashAdInterval = setInterval(showFlashAd, 60000);
        setTimeout(showFlashAd, 5000);
    }
}

function showPermanentAd() {
    if (adSettings.disableAll || permanentAdDisabled) return;
    if (adSettings.type !== "permanent" || !adSettings.flashEnabled || azanActive) return;
    hideAllScreens();
    let screen = document.getElementById('permanentAdScreen');
    let content = document.getElementById('permAdContent');
    if (screen && content) {
        if (adSettings.image) {
            screen.classList.add('flash-ad-no-frame');
            content.innerHTML = `<img src="${adSettings.image}" style="width:100%;height:100%;object-fit:cover">`;
        } else {
            screen.classList.remove('flash-ad-no-frame');
            content.innerHTML = `<div class="flash-ad-content-text">${adSettings.text}</div>`;
        }
        screen.style.display = 'flex';
        updateSettingsButtonVisibility(); updateTickerVisibility(); updateLogoVisibility();
    }
}

function stopAllAds() {
    if (flashAdInterval) clearInterval(flashAdInterval);
    const flashScreen = document.getElementById('flashAdScreen');
    const permScreen = document.getElementById('permanentAdScreen');
    if (flashScreen) flashScreen.style.display = 'none';
    if (permScreen) permScreen.style.display = 'none';
    updateSettingsButtonVisibility(); updateTickerVisibility(); updateLogoVisibility();
}

// ==================== 14. الأحاديث المنبثقة وأسماء الله الحسنى ====================
let popupType = "hadith";
let popupIndex = 0;

function splitTextIntoThreeLines(text) {
    const words = text.split(' ');
    const totalLength = text.length;
    const targetLength = Math.floor(totalLength / 3);
    let line1 = '', line2 = '', line3 = '';
    let currentLine = 1;
    let currentLength = 0;
    for (let word of words) {
        if (currentLine === 1 && currentLength + word.length > targetLength) { currentLine = 2; currentLength = 0; }
        else if (currentLine === 2 && currentLength + word.length > targetLength) { currentLine = 3; currentLength = 0; }
        if (currentLine === 1) line1 += (line1 ? ' ' : '') + word;
        else if (currentLine === 2) line2 += (line2 ? ' ' : '') + word;
        else line3 += (line3 ? ' ' : '') + word;
        currentLength += word.length + 1;
    }
    return { line1, line2, line3 };
}

function showPopup() {
    // منع ظهور الحديث المنبثق أثناء عرض الأذكار
    const adhkarScreen = document.getElementById('adhkarScreen');
    const morningAdhkarScreen = document.getElementById('morningAdhkarScreen');
    const eveningAdhkarScreen = document.getElementById('eveningAdhkarScreen');
    
    if (adhkarScreen && adhkarScreen.style.display === 'flex') return;
    if (morningAdhkarScreen && morningAdhkarScreen.style.display === 'flex') return;
    if (eveningAdhkarScreen && eveningAdhkarScreen.style.display === 'flex') return;
    
    if (!popupSettings.enabled || azanActive) return;
    
    let screen = document.getElementById('popupScreen');
    let textDiv = document.getElementById('popupText');
    
    if (screen && textDiv) {
        if (popupType === "hadith") {
            const hadith = hadithsList[popupIndex % hadithsList.length];
            const lines = splitTextIntoThreeLines(hadith.text);
            textDiv.innerHTML = `<div class="hadith-three-lines"><div class="line">${lines.line1}</div><div class="line">${lines.line2}</div><div class="line">${lines.line3}</div><div class="line hadith-source">${hadith.source}</div></div>`;
            popupIndex++;
        } else {
            const allahName = allahNamesList[popupIndex % allahNamesList.length];
            const lines = splitTextIntoThreeLines(allahName.meaning);
            textDiv.innerHTML = `<div class="hadith-three-lines"><div class="line" style="font-size:2rem; color:#D4AF37;">${allahName.name}</div><div class="line">${lines.line1}</div><div class="line">${lines.line2}</div><div class="line">${lines.line3}</div><div class="line hadith-source">اسم من أسماء الله الحسنى</div></div>`;
            popupIndex++;
        }
        
        screen.style.display = 'flex';
        updateSettingsButtonVisibility(); 
        updateTickerVisibility(); 
        updateLogoVisibility();
        
        setTimeout(() => { 
            if (screen) screen.style.display = 'none';
            updateSettingsButtonVisibility(); 
            updateTickerVisibility(); 
            updateLogoVisibility();
            popupType = (popupType === "hadith") ? "allahName" : "hadith";
        }, 20000);
    }
}  // <-- هذا القوس كان ناقصاً


function startPopupSystem() {
    if (popupTimer) clearInterval(popupTimer);
    if (popupSettings.enabled) {
        popupTimer = setInterval(showPopup, popupSettings.interval * 60000);
    }
}

// ==================== 15. الإطفاء التلقائي ====================
let isShutdownActive = false;
function checkShutdownTime() {
    if (!shutdownSettings.enabled) return;
    const now = new Date();
    const currentMin = now.getHours() * 60 + now.getMinutes();
    const [shH, shM] = shutdownSettings.shutdownTime.split(':').map(Number);
    const [wkH, wkM] = shutdownSettings.wakeupTime.split(':').map(Number);
    const shutdownMin = shH * 60 + shM;
    const wakeupMin = wkH * 60 + wkM;
    let shouldShutdown = false;
    if (wakeupMin < shutdownMin) {
        if (currentMin >= shutdownMin || currentMin < wakeupMin) shouldShutdown = true;
    } else {
        if (currentMin >= shutdownMin && currentMin < wakeupMin) shouldShutdown = true;
    }
    const shutdownScreen = document.getElementById('shutdownScreen');
    if (shouldShutdown) {
        if (!isShutdownActive) {
            isShutdownActive = true;
            if (shutdownScreen) shutdownScreen.style.display = 'flex';
            const weatherBox = document.getElementById('weatherBox');
            const prayerGrid = document.querySelector('.prayerGrid');
            const tickerContainer = document.getElementById('tickerContainer');
            if (weatherBox) weatherBox.style.display = 'none';
            if (prayerGrid) prayerGrid.style.display = 'none';
            if (tickerContainer) tickerContainer.style.display = 'none';
            updateSettingsButtonVisibility(); updateTickerVisibility(); updateLogoVisibility();
        }
    } else {
        if (isShutdownActive) {
            isShutdownActive = false;
            if (shutdownScreen) shutdownScreen.style.display = 'none';
            if (!azanActive) {
                const weatherBox = document.getElementById('weatherBox');
                const prayerGrid = document.querySelector('.prayerGrid');
                if (weatherBox) weatherBox.style.display = 'block';
                if (prayerGrid) prayerGrid.style.display = 'flex';
                updateTickerVisibility(); updateLogoVisibility();
            }
            updateSettingsButtonVisibility(); updateTickerVisibility(); updateLogoVisibility();
        }
    }
}
setInterval(checkShutdownTime, 1000);

// ==================== 16. دوال الدول والإعدادات ====================
function populateCountries() {
    const select = document.getElementById('countrySelect');
    if (!select) return;
    select.innerHTML = '';
    countriesList.forEach((c, idx) => {
        const opt = document.createElement('option');
        opt.value = c.code;
        opt.textContent = c.name;
        if (idx === 0) opt.selected = true;
        select.appendChild(opt);
    });
    select.onchange = () => {
        const code = select.value;
        const country = countriesList.find(c => c.code === code);
        currentCountry = country;
        populateCitiesForCountry(country);
    };
    currentCountry = countriesList[0];
    populateCitiesForCountry(currentCountry);
}

function populateCitiesForCountry(country) {
    const citySelect = document.getElementById('citySelect');
    if (!citySelect) return;
    citySelect.innerHTML = '';
    if (country.code === 'dz') {
        for (let wilaya in algeriaWilayas) {
            const opt = document.createElement('option');
            opt.value = wilaya;
            opt.textContent = wilaya;
            citySelect.appendChild(opt);
        }
        citySelect.onchange = () => {
            const wilaya = citySelect.value;
            currentCity = wilaya;
            const coords = algeriaCoordinates[wilaya];
            if (coords) { currentLat = coords.lat; currentLng = coords.lng; }
            updatePrayerTimes(); updateWeather();
        };
        if (citySelect.options.length) citySelect.selectedIndex = 0;
        currentCity = citySelect.value;
        const coords = algeriaCoordinates[currentCity];
        if (coords) { currentLat = coords.lat; currentLng = coords.lng; }
    } else {
        const defaultCity = country.defaultCity;
        const opt = document.createElement('option');
        opt.value = defaultCity;
        opt.textContent = defaultCity;
        citySelect.appendChild(opt);
        citySelect.onchange = () => {
            const cityName = citySelect.value;
            currentCity = cityName;
            const coords = worldCities[cityName];
            if (coords) { currentLat = coords.lat; currentLng = coords.lng; }
            updatePrayerTimes(); updateWeather();
        };
        currentCity = defaultCity;
        const coords = worldCities[defaultCity];
        if (coords) { currentLat = coords.lat; currentLng = coords.lng; }
    }
    currentMethodCode = country.methodCode;
    updatePrayerTimes(); updateWeather();
}

function saveAllSettings() {
    localStorage.setItem('adSettings', JSON.stringify(adSettings));
    localStorage.setItem('popupSettings', JSON.stringify(popupSettings));
    localStorage.setItem('prayerDurations', JSON.stringify(prayerDurations));
    localStorage.setItem('iqamaTimes', JSON.stringify(iqamaTimes));
    localStorage.setItem('fridaySettings', JSON.stringify(fridaySettings));
    localStorage.setItem('shutdownSettings', JSON.stringify(shutdownSettings));
    localStorage.setItem('prayerAdjust', JSON.stringify(prayerAdjust));
    localStorage.setItem('hijriAdjust', hijriAdjust);
    localStorage.setItem('asrSchool', asrSchool);
    localStorage.setItem('midnightMode', midnightMode);
    localStorage.setItem('highLatitudeMethod', highLatitudeMethod);
    const mosqueNameEl = document.getElementById('mosqueNameDisplay');
    if (mosqueNameEl) localStorage.setItem('mosqueName', mosqueNameEl.textContent);
    localStorage.setItem('currentCountryCode', currentCountry?.code);
    localStorage.setItem('currentCity', currentCity);
    localStorage.setItem('prayerMethod', prayerMethod);
    localStorage.setItem('currentMethodCode', currentMethodCode);
    localStorage.setItem('customFajrAngle', customFajrAngle);
    localStorage.setItem('customIshaAngle', customIshaAngle);
    if (prayerMethod === 'manual') localStorage.setItem('manualPrayerTimes', JSON.stringify(prayerTimes));
    console.log('✅ تم حفظ جميع الإعدادات');
}

function loadSettings() {
    const savedMosque = localStorage.getItem('mosqueName');
    const mosqueNameDisplay = document.getElementById('mosqueNameDisplay');
    const mosqueNameInput = document.getElementById('mosqueName');
    if (savedMosque && mosqueNameDisplay) mosqueNameDisplay.textContent = savedMosque;
    if (mosqueNameInput) mosqueNameInput.value = savedMosque || "اسم المسجد";
    
    const savedMethod = localStorage.getItem('prayerMethod');
    const autoRadio = document.querySelector('input[name="prayerMethod"][value="auto"]');
    const manualRadio = document.querySelector('input[name="prayerMethod"][value="manual"]');
    const autoSection = document.getElementById('autoPrayerSection');
    const manualSection = document.getElementById('manualPrayerSection');
    if (savedMethod === 'manual') {
        prayerMethod = 'manual';
        if (autoRadio) autoRadio.checked = false;
        if (manualRadio) manualRadio.checked = true;
        if (autoSection) autoSection.style.display = 'none';
        if (manualSection) manualSection.style.display = 'block';
        const savedManualTimes = localStorage.getItem('manualPrayerTimes');
        if (savedManualTimes) { prayerTimes = JSON.parse(savedManualTimes); updatePrayerDisplay(); }
    } else {
        prayerMethod = 'auto';
        if (autoRadio) autoRadio.checked = true;
        if (manualRadio) manualRadio.checked = false;
        if (autoSection) autoSection.style.display = 'block';
        if (manualSection) manualSection.style.display = 'none';
    }
    
    const savedCountry = localStorage.getItem('currentCountryCode');
    if (savedCountry) {
        const country = countriesList.find(c => c.code === savedCountry);
        if (country) {
            const select = document.getElementById('countrySelect');
            if (select) select.value = savedCountry;
            currentCountry = country;
            populateCitiesForCountry(country);
            const savedCity = localStorage.getItem('currentCity');
            if (savedCity) {
                const citySelect = document.getElementById('citySelect');
                if (citySelect) {
                    for (let i = 0; i < citySelect.options.length; i++) {
                        if (citySelect.options[i].value === savedCity) { citySelect.selectedIndex = i; break; }
                    }
                }
                currentCity = savedCity;
                if (currentCountry.code === 'dz') {
                    const coords = algeriaCoordinates[savedCity];
                    if (coords) { currentLat = coords.lat; currentLng = coords.lng; }
                } else {
                    const coords = worldCities[savedCity];
                    if (coords) { currentLat = coords.lat; currentLng = coords.lng; }
                }
            }
            updatePrayerTimes(); updateWeather();
        }
    }
    
    const savedMethodCode = localStorage.getItem('currentMethodCode');
    if (savedMethodCode) currentMethodCode = savedMethodCode;
    const savedFajrAngle = localStorage.getItem('customFajrAngle');
    if (savedFajrAngle) customFajrAngle = parseFloat(savedFajrAngle);
    const savedIshaAngle = localStorage.getItem('customIshaAngle');
    if (savedIshaAngle) customIshaAngle = parseFloat(savedIshaAngle);
    
    const savedAsrSchool = localStorage.getItem('asrSchool');
    if (savedAsrSchool !== null) asrSchool = parseInt(savedAsrSchool);
    const savedMidnightMode = localStorage.getItem('midnightMode');
    if (savedMidnightMode !== null) midnightMode = parseInt(savedMidnightMode);
    const savedHighLat = localStorage.getItem('highLatitudeMethod');
    if (savedHighLat) highLatitudeMethod = savedHighLat;
    
    const asrRadio0 = document.querySelector('input[name="asrMethod"][value="0"]');
    const asrRadio1 = document.querySelector('input[name="asrMethod"][value="1"]');
    if (asrRadio0 && asrRadio1) { if (asrSchool === 0) asrRadio0.checked = true; else asrRadio1.checked = true; }
    const midnightRadio1 = document.querySelector('input[name="midnightMethod"][value="1"]');
    const midnightRadio0 = document.querySelector('input[name="midnightMethod"][value="0"]');
    if (midnightRadio1 && midnightRadio0) { if (midnightMode === 1) midnightRadio1.checked = true; else midnightRadio0.checked = true; }
    const highLatSelect = document.getElementById('highLatitudeMethod');
    if (highLatSelect) highLatSelect.value = highLatitudeMethod;
    
    const savedIqama = localStorage.getItem('iqamaTimes');
    if (savedIqama) {
        iqamaTimes = JSON.parse(savedIqama);
        const fajrIqama = document.getElementById('fajrIqama');
        const dhuhrIqama = document.getElementById('dhuhrIqama');
        const asrIqama = document.getElementById('asrIqama');
        const maghribIqama = document.getElementById('maghribIqama');
        const ishaIqama = document.getElementById('ishaIqama');
        if (fajrIqama) fajrIqama.value = iqamaTimes.fajr;
        if (dhuhrIqama) dhuhrIqama.value = iqamaTimes.dhuhr;
        if (asrIqama) asrIqama.value = iqamaTimes.asr;
        if (maghribIqama) maghribIqama.value = iqamaTimes.maghrib;
        if (ishaIqama) ishaIqama.value = iqamaTimes.isha;
    }
    
    const savedDurations = localStorage.getItem('prayerDurations');
    if (savedDurations) {
        prayerDurations = JSON.parse(savedDurations);
        const fajrDuration = document.getElementById('fajrDuration');
        const dhuhrDuration = document.getElementById('dhuhrDuration');
        const asrDuration = document.getElementById('asrDuration');
        const maghribDuration = document.getElementById('maghribDuration');
        const ishaDuration = document.getElementById('ishaDuration');
        if (fajrDuration) fajrDuration.value = prayerDurations.fajr;
        if (dhuhrDuration) dhuhrDuration.value = prayerDurations.dhuhr;
        if (asrDuration) asrDuration.value = prayerDurations.asr;
        if (maghribDuration) maghribDuration.value = prayerDurations.maghrib;
        if (ishaDuration) ishaDuration.value = prayerDurations.isha;
    }
    
    const savedFriday = localStorage.getItem('fridaySettings');
    if (savedFriday) {
        fridaySettings = JSON.parse(savedFriday);
        const fridayHour = document.getElementById('fridayHour');
        const fridayMinute = document.getElementById('fridayMinute');
        const fridayDuration = document.getElementById('fridayDuration');
        if (fridayHour && fridayMinute) {
            const [hour, minute] = fridaySettings.time.split(':');
            fridayHour.value = hour; fridayMinute.value = minute;
        }
        if (fridayDuration) fridayDuration.value = fridaySettings.duration;
    }
    
    const savedShutdown = localStorage.getItem('shutdownSettings');
    if (savedShutdown) {
        shutdownSettings = JSON.parse(savedShutdown);
        const autoShutdown = document.getElementById('autoShutdown');
        const shutdownHour = document.getElementById('shutdownHour');
        const shutdownMinute = document.getElementById('shutdownMinute');
        const wakeupHour = document.getElementById('wakeupHour');
        const wakeupMinute = document.getElementById('wakeupMinute');
        if (autoShutdown) autoShutdown.checked = shutdownSettings.enabled;
        if (shutdownHour && shutdownMinute) {
            const [hour, minute] = shutdownSettings.shutdownTime.split(':');
            shutdownHour.value = hour; shutdownMinute.value = minute;
        }
        if (wakeupHour && wakeupMinute) {
            const [hour, minute] = shutdownSettings.wakeupTime.split(':');
            wakeupHour.value = hour; wakeupMinute.value = minute;
        }
    }
    
    const savedPopup = localStorage.getItem('popupSettings');
    if (savedPopup) {
        popupSettings = JSON.parse(savedPopup);
        const enablePopup = document.getElementById('enablePopup');
        const popupInterval = document.getElementById('popupInterval');
        if (enablePopup) enablePopup.checked = popupSettings.enabled;
        if (popupInterval) popupInterval.value = popupSettings.interval;
    }
    
    const savedAd = localStorage.getItem('adSettings');
    if (savedAd) {
        adSettings = JSON.parse(savedAd);
        const disableAllAds = document.getElementById('disableAllAds');
        const enableTicker = document.getElementById('enableTicker');
        const enableFlashAd = document.getElementById('enableFlashAd');
        const tickerTextInput = document.getElementById('tickerTextInput');
        const adText = document.getElementById('adText');
        if (disableAllAds) disableAllAds.checked = adSettings.disableAll;
        if (enableTicker) enableTicker.checked = adSettings.tickerEnabled;
        if (enableFlashAd) enableFlashAd.checked = adSettings.flashEnabled;
        if (tickerTextInput) tickerTextInput.value = adSettings.tickerText;
        if (adText) adText.value = adSettings.text;
        const tickerDirectionRadios = document.querySelectorAll('input[name="tickerDirection"]');
        tickerDirectionRadios.forEach(radio => { if (radio.value === adSettings.tickerDirection) radio.checked = true; });
        const adTypeRadios = document.querySelectorAll('input[name="adType"]');
        adTypeRadios.forEach(radio => { if (radio.value === adSettings.type) radio.checked = true; });
        if (enableTicker) enableTicker.dispatchEvent(new Event('change'));
        if (enableFlashAd) enableFlashAd.dispatchEvent(new Event('change'));
        if (disableAllAds) disableAllAds.dispatchEvent(new Event('change'));
    }
    
    const savedAdjust = localStorage.getItem('prayerAdjust');
    if (savedAdjust) {
        prayerAdjust = JSON.parse(savedAdjust);
        const fajrAdjust = document.getElementById('fajrAdjust');
        const dhuhrAdjust = document.getElementById('dhuhrAdjust');
        const asrAdjust = document.getElementById('asrAdjust');
        const maghribAdjust = document.getElementById('maghribAdjust');
        const ishaAdjust = document.getElementById('ishaAdjust');
        if (fajrAdjust) fajrAdjust.value = prayerAdjust.fajr;
        if (dhuhrAdjust) dhuhrAdjust.value = prayerAdjust.dhuhr;
        if (asrAdjust) asrAdjust.value = prayerAdjust.asr;
        if (maghribAdjust) maghribAdjust.value = prayerAdjust.maghrib;
        if (ishaAdjust) ishaAdjust.value = prayerAdjust.isha;
    }
    
    const savedPermanentAdDisabled = localStorage.getItem('permanentAdDisabled');
    if (savedPermanentAdDisabled === 'true') permanentAdDisabled = true;
    else permanentAdDisabled = false;
    
    const savedHijri = localStorage.getItem('hijriAdjust');
    if (savedHijri !== null) hijriAdjust = parseInt(savedHijri);
    
    loadBackground();
    updatePrayerDisplay();
    updateDateDisplay();
    updateWeather();
    startTicker();
    updateTickerVisibility();
    updateLogoVisibility();
    startAdSystem();
    startHadithRotation();
    if (!adSettings.disableAll && !permanentAdDisabled && adSettings.type === "permanent" && adSettings.flashEnabled) showPermanentAd();
    console.log('✅ تم تحميل جميع الإعدادات');
}

// ==================== 17. أحداث الإعدادات ====================
function setupSettingsEvents() {
    const settingsBtn = document.getElementById('onlySettingsBtn');
    if (settingsBtn) {
        settingsBtn.addEventListener('click', function(e) {
            e.stopPropagation(); e.preventDefault();
            const settingsScreen = document.getElementById('settingsScreen');
            if (settingsScreen) settingsScreen.style.display = 'flex';
            updateTickerVisibility(); updateSettingsButtonVisibility(); updateLogoVisibility();
        });
    }
    
    const disableAdBtn = document.getElementById('disableAdPermanentBtn');
    if (disableAdBtn) {
        disableAdBtn.addEventListener('click', () => {
            if (confirm('⚠️ هل تريد تعطيل الإعلان نهائياً؟')) {
                permanentAdDisabled = true; adSettings.disableAll = true;
                localStorage.setItem('permanentAdDisabled', 'true');
                stopAllAds(); startTicker();
                alert('✅ تم تعطيل الإعلان نهائياً');
            }
        });
    }
    
    document.querySelectorAll('.close-settings').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.settings-screen, .settings-page').forEach(el => { if (el) el.style.display = 'none'; });
            updateTickerVisibility(); updateSettingsButtonVisibility(); updateLogoVisibility();
        };
    });
    
    document.querySelectorAll('.back-btn').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.settings-page').forEach(el => { if (el) el.style.display = 'none'; });
            const settingsScreen = document.getElementById('settingsScreen');
            if (settingsScreen) settingsScreen.style.display = 'flex';
            updateTickerVisibility(); updateSettingsButtonVisibility(); updateLogoVisibility();
        };
    });
    
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        item.onclick = () => {
            const section = item.dataset.section;
            const settingsScreen = document.getElementById('settingsScreen');
            const page = document.getElementById(`page-${section}`);
            if (settingsScreen) settingsScreen.style.display = 'none';
            if (page) { page.style.display = 'flex'; updateTickerVisibility(); updateSettingsButtonVisibility(); updateLogoVisibility(); }
        };
    });
    
    const calculationMethodSelect = document.getElementById('calculationMethod');
    const angleInputsDiv = document.getElementById('angleInputs');
    function updateAngleInputsVisibility() {
        if (calculationMethodSelect && angleInputsDiv) {
            const val = calculationMethodSelect.value;
            angleInputsDiv.style.display = val === '99' ? 'block' : 'none';
        }
    }
    if (calculationMethodSelect) {
        calculationMethodSelect.onchange = () => {
            currentMethodCode = calculationMethodSelect.value;
            if (currentMethodCode === '99') {
                customFajrAngle = parseFloat(document.getElementById('customFajrAngle').value);
                customIshaAngle = parseFloat(document.getElementById('customIshaAngle').value);
            }
            updateAngleInputsVisibility();
            updatePrayerTimes();
        };
        updateAngleInputsVisibility();
    }
    
    const prayerMethodRadios = document.querySelectorAll('input[name="prayerMethod"]');
    prayerMethodRadios.forEach(radio => {
        radio.onchange = () => {
            const isAuto = radio.value === 'auto';
            prayerMethod = isAuto ? 'auto' : 'manual';
            const autoSection = document.getElementById('autoPrayerSection');
            const manualSection = document.getElementById('manualPrayerSection');
            if (autoSection) autoSection.style.display = isAuto ? 'block' : 'none';
            if (manualSection) manualSection.style.display = isAuto ? 'none' : 'block';
            if (!isAuto) {
                const fajrHour = document.getElementById('fajrHour');
                const fajrMinute = document.getElementById('fajrMinute');
                const dhuhrHour = document.getElementById('dhuhrHour');
                const dhuhrMinute = document.getElementById('dhuhrMinute');
                const asrHour = document.getElementById('asrHour');
                const asrMinute = document.getElementById('asrMinute');
                const maghribHour = document.getElementById('maghribHour');
                const maghribMinute = document.getElementById('maghribMinute');
                const ishaHour = document.getElementById('ishaHour');
                const ishaMinute = document.getElementById('ishaMinute');
                if (fajrHour) fajrHour.value = prayerTimes.fajr.split(':')[0];
                if (fajrMinute) fajrMinute.value = prayerTimes.fajr.split(':')[1];
                if (dhuhrHour) dhuhrHour.value = prayerTimes.dhuhr.split(':')[0];
                if (dhuhrMinute) dhuhrMinute.value = prayerTimes.dhuhr.split(':')[1];
                if (asrHour) asrHour.value = prayerTimes.asr.split(':')[0];
                if (asrMinute) asrMinute.value = prayerTimes.asr.split(':')[1];
                if (maghribHour) maghribHour.value = prayerTimes.maghrib.split(':')[0];
                if (maghribMinute) maghribMinute.value = prayerTimes.maghrib.split(':')[1];
                if (ishaHour) ishaHour.value = prayerTimes.isha.split(':')[0];
                if (ishaMinute) ishaMinute.value = prayerTimes.isha.split(':')[1];
            } else updatePrayerTimes();
        };
    });
    
    const saveBtns = document.querySelectorAll('.save-btn');
    saveBtns.forEach(btn => {
        btn.onclick = () => {
            const page = btn.dataset.page;
            if (page === 'mosque') {
                const nameInput = document.getElementById('mosqueName');
                const nameDisplay = document.getElementById('mosqueNameDisplay');
                if (nameInput && nameDisplay) nameDisplay.textContent = nameInput.value;
                alert('✅ تم حفظ اسم المسجد');
            }
            if (page === 'prayer') {
                const methodRadio = document.querySelector('input[name="prayerMethod"]:checked');
                if (methodRadio) {
                    if (methodRadio.value === 'auto') {
                        prayerMethod = 'auto';
                        const calcMethodSelect = document.getElementById('calculationMethod');
                        if (calcMethodSelect) {
                            currentMethodCode = calcMethodSelect.value;
                            if (currentMethodCode === '99') {
                                customFajrAngle = parseFloat(document.getElementById('customFajrAngle').value);
                                customIshaAngle = parseFloat(document.getElementById('customIshaAngle').value);
                            }
                        }
                        const asrRadio = document.querySelector('input[name="asrMethod"]:checked');
                        if (asrRadio) asrSchool = parseInt(asrRadio.value);
                        const midnightRadio = document.querySelector('input[name="midnightMethod"]:checked');
                        if (midnightRadio) midnightMode = parseInt(midnightRadio.value);
                        const highLatSelect = document.getElementById('highLatitudeMethod');
                        if (highLatSelect) highLatitudeMethod = highLatSelect.value;
                        updatePrayerTimes();
                    } else {
                        prayerMethod = 'manual';
                        const fajrHour = document.getElementById('fajrHour');
                        const fajrMinute = document.getElementById('fajrMinute');
                        const dhuhrHour = document.getElementById('dhuhrHour');
                        const dhuhrMinute = document.getElementById('dhuhrMinute');
                        const asrHour = document.getElementById('asrHour');
                        const asrMinute = document.getElementById('asrMinute');
                        const maghribHour = document.getElementById('maghribHour');
                        const maghribMinute = document.getElementById('maghribMinute');
                        const ishaHour = document.getElementById('ishaHour');
                        const ishaMinute = document.getElementById('ishaMinute');
                        if (fajrHour && fajrMinute) prayerTimes.fajr = `${fajrHour.value.padStart(2, '0')}:${fajrMinute.value.padStart(2, '0')}`;
                        if (dhuhrHour && dhuhrMinute) prayerTimes.dhuhr = `${dhuhrHour.value.padStart(2, '0')}:${dhuhrMinute.value.padStart(2, '0')}`;
                        if (asrHour && asrMinute) prayerTimes.asr = `${asrHour.value.padStart(2, '0')}:${asrMinute.value.padStart(2, '0')}`;
                        if (maghribHour && maghribMinute) prayerTimes.maghrib = `${maghribHour.value.padStart(2, '0')}:${maghribMinute.value.padStart(2, '0')}`;
                        if (ishaHour && ishaMinute) prayerTimes.isha = `${ishaHour.value.padStart(2, '0')}:${ishaMinute.value.padStart(2, '0')}`;
                        updatePrayerDisplay();
                    }
                }
                const fajrAdjust = document.getElementById('fajrAdjust');
                const dhuhrAdjust = document.getElementById('dhuhrAdjust');
                const asrAdjust = document.getElementById('asrAdjust');
                const maghribAdjust = document.getElementById('maghribAdjust');
                const ishaAdjust = document.getElementById('ishaAdjust');
                if (fajrAdjust) prayerAdjust.fajr = parseInt(fajrAdjust.value);
                if (dhuhrAdjust) prayerAdjust.dhuhr = parseInt(dhuhrAdjust.value);
                if (asrAdjust) prayerAdjust.asr = parseInt(asrAdjust.value);
                if (maghribAdjust) prayerAdjust.maghrib = parseInt(maghribAdjust.value);
                if (ishaAdjust) prayerAdjust.isha = parseInt(ishaAdjust.value);
                if (methodRadio && methodRadio.value === 'auto') updatePrayerTimes();
                updateCountdown();
                alert('✅ تم حفظ إعدادات الصلاة');
            }
            if (page === 'iqama') {
                const fajrIqama = document.getElementById('fajrIqama');
                const dhuhrIqama = document.getElementById('dhuhrIqama');
                const asrIqama = document.getElementById('asrIqama');
                const maghribIqama = document.getElementById('maghribIqama');
                const ishaIqama = document.getElementById('ishaIqama');
                const fajrDuration = document.getElementById('fajrDuration');
                const dhuhrDuration = document.getElementById('dhuhrDuration');
                const asrDuration = document.getElementById('asrDuration');
                const maghribDuration = document.getElementById('maghribDuration');
                const ishaDuration = document.getElementById('ishaDuration');
                if (fajrIqama) iqamaTimes.fajr = parseInt(fajrIqama.value);
                if (dhuhrIqama) iqamaTimes.dhuhr = parseInt(dhuhrIqama.value);
                if (asrIqama) iqamaTimes.asr = parseInt(asrIqama.value);
                if (maghribIqama) iqamaTimes.maghrib = parseInt(maghribIqama.value);
                if (ishaIqama) iqamaTimes.isha = parseInt(ishaIqama.value);
                if (fajrDuration) prayerDurations.fajr = parseInt(fajrDuration.value);
                if (dhuhrDuration) prayerDurations.dhuhr = parseInt(dhuhrDuration.value);
                if (asrDuration) prayerDurations.asr = parseInt(asrDuration.value);
                if (maghribDuration) prayerDurations.maghrib = parseInt(maghribDuration.value);
                if (ishaDuration) prayerDurations.isha = parseInt(ishaDuration.value);
                alert('✅ تم حفظ مدة الإقامة ومدة الصلاة');
            }
            if (page === 'friday') {
                const fridayHour = document.getElementById('fridayHour');
                const fridayMinute = document.getElementById('fridayMinute');
                const fridayDuration = document.getElementById('fridayDuration');
                if (fridayHour && fridayMinute) fridaySettings.time = `${fridayHour.value.padStart(2, '0')}:${fridayMinute.value.padStart(2, '0')}`;
                if (fridayDuration) fridaySettings.duration = parseInt(fridayDuration.value);
                updatePrayerDisplay();
                alert('✅ تم حفظ صلاة الجمعة');
            }
            if (page === 'shutdown') {
                const autoShutdown = document.getElementById('autoShutdown');
                const shutdownHour = document.getElementById('shutdownHour');
                const shutdownMinute = document.getElementById('shutdownMinute');
                const wakeupHour = document.getElementById('wakeupHour');
                const wakeupMinute = document.getElementById('wakeupMinute');
                if (autoShutdown) shutdownSettings.enabled = autoShutdown.checked;
                if (shutdownHour && shutdownMinute) shutdownSettings.shutdownTime = `${shutdownHour.value.padStart(2, '0')}:${shutdownMinute.value.padStart(2, '0')}`;
                if (wakeupHour && wakeupMinute) shutdownSettings.wakeupTime = `${wakeupHour.value.padStart(2, '0')}:${wakeupMinute.value.padStart(2, '0')}`;
                alert('✅ تم حفظ الإطفاء التلقائي');
            }
            if (page === 'background') {
                const bgTypeRadio = document.querySelector('input[name="bgType"]:checked');
                if (bgTypeRadio) {
                    const type = bgTypeRadio.value;
                    if (type === 'gallery') {
                        const imageSelect = document.getElementById('imageSelect');
                        if (imageSelect) applyBackground('gallery', imageSelect.value);
                    } else if (type === 'custom' && window.customBg) applyBackground('custom', window.customBg);
                }
                alert('✅ تم تطبيق الخلفية');
            }
            if (page === 'ads') {
                const disableAllAds = document.getElementById('disableAllAds');
                const enableTicker = document.getElementById('enableTicker');
                const enableFlashAd = document.getElementById('enableFlashAd');
                const adTypeRadio = document.querySelector('input[name="adType"]:checked');
                if (disableAllAds) adSettings.disableAll = disableAllAds.checked;
                if (enableTicker) adSettings.tickerEnabled = enableTicker.checked;
                if (enableFlashAd) adSettings.flashEnabled = enableFlashAd.checked;
                if (adSettings.flashEnabled) {
                    const adText = document.getElementById('adText');
                    const adImage = document.getElementById('adImage');
                    if (adTypeRadio) adSettings.type = adTypeRadio.value;
                    if (adText) adSettings.text = adText.value;
                    if (adImage && adImage.files && adImage.files[0]) {
                        const reader = new FileReader();
                        reader.onload = (e) => { adSettings.image = e.target.result; };
                        reader.readAsDataURL(adImage.files[0]);
                    } else adSettings.image = null;
                } else adSettings.image = null;
                if (adSettings.tickerEnabled) {
                    const tickerTextInput = document.getElementById('tickerTextInput');
                    const tickerDirectionRadio = document.querySelector('input[name="tickerDirection"]:checked');
                    if (tickerTextInput) adSettings.tickerText = tickerTextInput.value;
                    if (tickerDirectionRadio) adSettings.tickerDirection = tickerDirectionRadio.value;
                }
                if (!adSettings.disableAll && adSettings.flashEnabled) { permanentAdDisabled = false; localStorage.removeItem('permanentAdDisabled'); }
                startTicker(); stopAllAds();
                if (adSettings.flashEnabled && !adSettings.disableAll && !permanentAdDisabled) {
                    if (adSettings.type === "flash") startAdSystem();
                    else if (adSettings.type === "permanent") showPermanentAd();
                }
                alert('✅ تم حفظ الإعلانات');
            }
            if (page === 'hadith') {
                const enablePopup = document.getElementById('enablePopup');
                const popupInterval = document.getElementById('popupInterval');
                if (enablePopup) popupSettings.enabled = enablePopup.checked;
                if (popupInterval) popupSettings.interval = parseInt(popupInterval.value);
                startPopupSystem();
                alert('✅ تم حفظ إعدادات الأحاديث المنبثقة وأسماء الله الحسنى');
            }
            if (page === 'hijri') {
                const hijriAdjustInput = document.getElementById('hijriAdjust');
                if (hijriAdjustInput) { hijriAdjust = parseInt(hijriAdjustInput.value); updateDateDisplay(); }
                alert('✅ تم ضبط التاريخ الهجري');
            }
            saveAllSettings();
        };
    });
    
    const customImageFile = document.getElementById('customImageFile');
    if (customImageFile) {
        customImageFile.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (ev) => {
                    const preview = document.getElementById('customImagePreview');
                    if (preview) preview.innerHTML = `<img src="${ev.target.result}" style="max-width:100%; max-height:100px;">`;
                    window.customBg = ev.target.result;
                };
                reader.readAsDataURL(file);
            }
        };
    }
    
    const adjustBtns = document.querySelectorAll('.adjust-minus-large, .adjust-plus-large');
    adjustBtns.forEach(btn => {
        btn.onclick = () => {
            const targetId = btn.dataset.target;
            const input = document.getElementById(targetId);
            if (input) {
                let val = parseInt(input.value) || 0;
                if (btn.classList.contains('adjust-minus-large')) val--;
                else val++;
                if (val < -99) val = -99;
                if (val > 99) val = 99;
                input.value = val;
            }
        };
    });
    
    const hijriAdjustBtns = document.querySelectorAll('.adjust-btn');
    hijriAdjustBtns.forEach(btn => {
        btn.onclick = () => {
            hijriAdjust = parseInt(btn.dataset.value);
            updateDateDisplay();
            saveAllSettings();
            alert(`✅ تم ضبط التاريخ الهجري ${hijriAdjust > 0 ? '+' : ''}${hijriAdjust} يوم`);
        };
    });
    
    const enableTicker = document.getElementById('enableTicker');
    if (enableTicker) {
        enableTicker.onchange = () => {
            const tickerSettings = document.getElementById('tickerSettings');
            if (tickerSettings) tickerSettings.style.display = enableTicker.checked ? 'block' : 'none';
            startTicker();
        };
    }
    
    const enableFlashAd = document.getElementById('enableFlashAd');
    if (enableFlashAd) {
        enableFlashAd.onchange = () => {
            const flashSettings = document.getElementById('flashSettings');
            if (flashSettings) flashSettings.style.display = enableFlashAd.checked ? 'block' : 'none';
        };
    }
    
    const disableAllAds = document.getElementById('disableAllAds');
    if (disableAllAds) {
        disableAllAds.onchange = () => {
            const allDisabled = disableAllAds.checked;
            if (allDisabled) { stopAllAds(); startTicker(); }
            else { startAdSystem(); if (!permanentAdDisabled && adSettings.type === "permanent" && adSettings.flashEnabled) showPermanentAd(); startTicker(); }
        };
    }
    
    const bgTypeRadios = document.querySelectorAll('input[name="bgType"]');
    bgTypeRadios.forEach(radio => {
        radio.onchange = () => {
            const val = document.querySelector('input[name="bgType"]:checked').value;
            const gallerySection = document.getElementById('gallerySection');
            const customImageSection = document.getElementById('customImageSection');
            if (gallerySection) gallerySection.style.display = val === 'gallery' ? 'block' : 'none';
            if (customImageSection) customImageSection.style.display = val === 'custom' ? 'block' : 'none';
        };
    });
}

// ==================== 18. دوال إظهار العناصر ====================
function updateSettingsButtonVisibility() {
    const settingsBtn = document.getElementById('onlySettingsBtn');
    if (!settingsBtn) return;
  
    const hiddenScreens = [
        'splashScreen', 'azanScreen', 'duaScreen', 'iqamaCountdownScreen', 'iqamaScreen',
        'prayerScreen', 'adhkarScreen', 'popupScreen', 'morningAdhkarScreen',
        'eveningAdhkarScreen', 'fridayScreen', 'shutdownScreen', 'flashAdScreen',
        'permanentAdScreen'
    ];
    
    let shouldHide = false;
    
    for (let screenId of hiddenScreens) {
        const screen = document.getElementById(screenId);
        if (screen && screen.style.display === 'flex') {
            shouldHide = true;
            break;
        }
    }
    
    const settingsScreen = document.getElementById('settingsScreen');
    if (settingsScreen && settingsScreen.style.display === 'flex') {
        shouldHide = true;
    }
    
    const settingsPages = document.querySelectorAll('.settings-page');
    for (let page of settingsPages) {
        if (page && page.style.display === 'flex') {
            shouldHide = true;
            break;
        }
    }
    
    settingsBtn.style.display = shouldHide ? 'none' : 'flex';
}

function updateLogoVisibility() {
    const logo = document.getElementById('permanentLogo');
    if (!logo) return;
    
    const hiddenScreens = [
        'splashScreen', 'azanScreen', 'duaScreen', 'iqamaCountdownScreen', 'iqamaScreen',
        'prayerScreen', 'adhkarScreen', 'popupScreen', 'morningAdhkarScreen',
        'eveningAdhkarScreen', 'fridayScreen', 'shutdownScreen', 'flashAdScreen',
        'permanentAdScreen'
    ];
    
    let shouldHide = false;
    
    const splash = document.getElementById('splashScreen');
    if (splash && splash.style.display !== 'none') {
        shouldHide = true;
    }
    
    for (let screenId of hiddenScreens) {
        const screen = document.getElementById(screenId);
        if (screen && screen.style.display === 'flex') {
            shouldHide = true;
            break;
        }
    }
    
    const settingsScreen = document.getElementById('settingsScreen');
    if (settingsScreen && settingsScreen.style.display === 'flex') {
        shouldHide = true;
    }
    
    const settingsPages = document.querySelectorAll('.settings-page');
    for (let page of settingsPages) {
        if (page && page.style.display === 'flex') {
            shouldHide = true;
            break;
        }
    }
    
    logo.style.display = shouldHide ? 'none' : 'flex';
}

function startTicker() {
    const container = document.getElementById('tickerContainer');
    const textEl = document.getElementById('tickerText');
    
    const splash = document.getElementById('splashScreen');
    if (splash && splash.style.display !== 'none') {
        if (container) container.style.display = 'none';
        return;
    }
    
    if (!container || !textEl) return;
    
    if (adSettings.disableAll || !adSettings.tickerEnabled) {
        container.style.display = 'none';
        return;
    }
    
    textEl.textContent = adSettings.tickerText || 'مرحباً بكم في مسجد التقوى';
    const direction = adSettings.tickerDirection || 'rtl';
    textEl.classList.remove('ltr', 'rtl');
    textEl.classList.add(direction);
    container.style.display = 'flex';
}

function updateTickerVisibility() {
    const container = document.getElementById('tickerContainer');
    if (!container) return;
    
    const splash = document.getElementById('splashScreen');
    if (splash && splash.style.display !== 'none') {
        container.style.display = 'none';
        return;
    }
    
    const hiddenScreens = [
        'azanScreen', 'duaScreen', 'iqamaCountdownScreen', 'iqamaScreen',
        'prayerScreen', 'adhkarScreen', 'popupScreen', 'morningAdhkarScreen',
        'eveningAdhkarScreen', 'fridayScreen', 'shutdownScreen', 'flashAdScreen',
        'permanentAdScreen', 'settingsScreen'
    ];
    
    let shouldHide = false;
    
    for (let screenId of hiddenScreens) {
        const screen = document.getElementById(screenId);
        if (screen && screen.style.display === 'flex') {
            shouldHide = true;
            break;
        }
    }
    
    const settingsPages = document.querySelectorAll('.settings-page');
    for (let page of settingsPages) {
        if (page && page.style.display === 'flex') {
            shouldHide = true;
            break;
        }
    }
    
    if (shouldHide) {
        container.style.display = 'none';
    } else {
        if (adSettings.tickerEnabled && !adSettings.disableAll) {
            container.style.display = 'flex';
        } else {
            container.style.display = 'none';
        }
    }
}

// ==================== 19. التهيئة النهائية ====================
setInterval(updateClock, 1000);
setInterval(updateCountdown, 1000);

function initApp() {
    populateCountries();
    updatePrayerDisplay();
    loadSettings();
    setupSettingsEvents();
    startHadithRotation();
    startAdSystem();
    startDateToggle();
    populateImageSelect();
    startPrayerMonitoring();
    
    const enableTicker = document.getElementById('enableTicker');
    if (enableTicker) enableTicker.dispatchEvent(new Event('change'));
    const enableFlashAd = document.getElementById('enableFlashAd');
    if (enableFlashAd) enableFlashAd.dispatchEvent(new Event('change'));
    const enablePopup = document.getElementById('enablePopup');
    if (enablePopup) enablePopup.dispatchEvent(new Event('change'));
    const bgTypeRadio = document.querySelector('input[name="bgType"]:checked');
    if (bgTypeRadio) bgTypeRadio.dispatchEvent(new Event('change'));
    
    updatePrayerTimes();
    updateClock();
    updateCountdown();
    updateSettingsButtonVisibility();
    updateLogoVisibility();
    
    // تأخير ظهور الأحاديث المنبثقة لمدة 4 دقائق
    setTimeout(() => {
        startPopupSystem();
        console.log('✅ تم بدء نظام الأحاديث المنبثقة بعد 4 دقائق');
    }, 240000);
    
    console.log('✅ التطبيق جاهز');
}

document.addEventListener('DOMContentLoaded', () => {
    const mainApp = document.getElementById('mainAppContent');
    const tickerContainer = document.getElementById('tickerContainer');
    const settingsBtn = document.getElementById('onlySettingsBtn');
    
    if (mainApp) mainApp.style.display = 'flex';
    if (tickerContainer) tickerContainer.style.display = 'none';
    if (settingsBtn) settingsBtn.style.display = 'flex';
    
    initApp();
    
    setTimeout(() => {
        const splash = document.getElementById('splashScreen');
        if (splash) splash.style.display = 'none';
        
        setTimeout(() => {
            startTicker();
            const settingsBtnAfterSplash = document.getElementById('onlySettingsBtn');
            if (settingsBtnAfterSplash) settingsBtnAfterSplash.style.display = 'flex';
            updateLogoVisibility();
        }, 200);
    }, 8000);
});